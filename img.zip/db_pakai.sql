-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2022 at 05:39 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_pakai`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(4) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `koor` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telpon` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama`, `nip`, `koor`, `jabatan`, `email`, `telpon`, `username`, `password`) VALUES
(1, 'Admin', '', '', '', '', '', 'admin', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_brg` int(4) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `nup` varchar(4) NOT NULL,
  `tipe` varchar(50) NOT NULL,
  `sn` varchar(12) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `keterangan` varchar(22) NOT NULL,
  `ketersediaan` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_brg`, `kode_barang`, `nama_barang`, `nup`, `tipe`, `sn`, `tahun`, `keterangan`, `ketersediaan`) VALUES
(1, '3100102002', 'Lap Top', '109', 'Lenovo V14 Gen2, i7,4G+8G, 1T+256G', '121212', '2019', '121212', 0),
(7, '3100102002', 'Lap Top', '90', 'Dell Latitude 5290 (i5,4GB,1TB,Win10Pro,12.5In)   ', 'XVVEI', '2019', 'bxbxbx1', 1),
(8, '3100102002', 'Lap Top', '77', 'Dell Business Notebook Vostro 14 5468 Wi 10', '1ZTFXF2', '2017', 'Engsel Rusak', 1),
(9, '3000000001', 'ALAT TESTER', '1', 'Mesin tester', '2122', '2022', 'Normal', 1);

-- --------------------------------------------------------

--
-- Table structure for table `barang2`
--

CREATE TABLE `barang2` (
  `id_kode` int(4) NOT NULL,
  `kode_barang` varchar(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang2`
--

INSERT INTO `barang2` (`id_kode`, `kode_barang`, `nama_barang`) VALUES
(59, '3000000001', 'TESTER BARANG'),
(20, '3050101001', 'Mesin Ketik Manual Portable (11-13 Inci)'),
(21, '3050101003', 'Mesin Ketik Manual Langewagon (18-27 Inci)'),
(24, '3050105015', 'Alat Penghancur Kertas'),
(25, '3050105024', 'Alat Pemotong Kertas'),
(26, '3050105038', 'Laser Pointer'),
(28, '3050105052', 'Alat Perekam Suara (Voice Pen)'),
(29, '3050206004', 'Tape Recorder (Alat Rumah Tangga Lainnya ( Home Us'),
(30, '3050206007', 'Loudspeaker'),
(31, '3050206008', 'Sound System'),
(32, '3050206012', 'Wireless'),
(33, '3050206013', 'Megaphone'),
(34, '3050206014', 'Microphone'),
(35, '3050206015', 'Microphone Table Stand'),
(36, '3050206016', 'Mic Conference'),
(51, '3050206020', 'Camera Video'),
(54, '3050206021', 'Tustel'),
(37, '3050206046', 'Handy Cam'),
(38, '3060101002', 'Audio Mixing Portable'),
(39, '3060101036', 'Microphone/Wireless MIC'),
(40, '3060101037', 'Microphone/Boom Stand'),
(41, '3060101088', 'Voice Recorder'),
(42, '3060102045', 'Tripod Camera'),
(43, '3060102061', 'Lensa Kamera'),
(44, '3060102069', 'Tele Recorder'),
(45, '3060102128', 'Camera Digital'),
(46, '3100102002', 'Lap Top'),
(57, '3100102002', 'Lifebook Fujitsu UH554 Black'),
(53, '3100203003', 'Printer (Peralatan Personal Komputer)');

-- --------------------------------------------------------

--
-- Table structure for table `datapegawai`
--

CREATE TABLE `datapegawai` (
  `id_peg` int(11) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jabatan` varchar(65) NOT NULL,
  `koor` varchar(65) NOT NULL,
  `ruang` varchar(52) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `datapegawai`
--

INSERT INTO `datapegawai` (`id_peg`, `nip`, `nama`, `jabatan`, `koor`, `ruang`) VALUES
(1, '196407041987011001', 'dr. Ivan Rovian, M.Kp', 'Kepala Bagian Umum', 'Kepala Bagian Umum', 'Kepala Bagian Umum'),
(2, '196211221982032001', 'Dra. Ec. Yayuk Suci Rahayu, M.A.', 'Koordinator Tata Usaha dan Kearsipan', 'Koordinator Tata Usaha dan Kearsipan', 'Tata Usaha dan Kearsipan'),
(3, '196307121983032002', 'Hj. Anik Nuryani, S.E.', 'Koordinator Kelembagaan dan Sistem Informasi Perguruan Tinggi Vok', 'Kelembagaan dan Sistem Informasi Perguruan Tinggi Vokasi', 'Pusat Informasi dan Layanan Terp'),
(4, '196401141989021001', 'Purnomo, S.H., M.H.', 'Koordinator Hukum, Humas, dan Kerjasama', 'Hukum, Humas, dan Kerjasama', 'BMN dan Sarpras'),
(5, '196503141985032001', 'Ida Ayu Siti Hamidah, S.H.', 'Koordinator Kemahasiswaan', 'Koordinator Kemahasiswaan', ''),
(6, '198111252010121002', 'Indera Zainul Muttaqien, S.T., M.Kom.', 'Koordinator Akademik dan Risbang', 'Koordinator Akademik dan Risbang', ''),
(7, '198110112009121002', 'Muhammad Machmud, S.Kom., M.Kom.', 'Koordinator Sertifikasi dan Mutu Pendidik', 'Koordinator Sertifikasi dan Mutu Pendidik', ''),
(8, '197911152008121002', 'Thohari, S.Kom', 'Koordinator Kelembagaan dan Sistem Informasi Perguruan Tinggi', 'Koordinator Kelembagaan dan Sistem Informasi Perguruan Tinggi', ''),
(9, '197602162010122001', 'Mayastuti, S.E., MSM', 'Koordinator Layanan Ketenagaan', 'Koordinator Kelembagaan dan Sistem Informasi Perguruan Tinggi', ''),
(10, '198501122010121006', 'Agung Yundi Bahuda Sistawan, S.H', 'Koordinator Kepegawaian, dan Tata Laksana', 'Koordinator Kepegawaian, dan Tata Laksana', ''),
(11, '198406252008121002', 'Erdianto Setyo Wahyono, R., S.E., M.SA', 'Koordinator BMN dan Sarpras', 'BMN dan Sarpras', ''),
(12, '198504182009122005', 'Yudianto Wicaksono, S.E., M.Ak', 'Koordinator Keuangan', 'Koordinator Keuangan', ''),
(13, '198503192009122003', 'Ratna Dwi Anggarwati, S.Sos.', 'Koordinator Renggar dan Pelaporan', 'Koordinator Renggar dan Pelaporan', ''),
(15, '196704192005012001', '‪Prof. Dr. Dyah Sawitri, S.E., M.M.', 'Kepala', 'Kepala', ''),
(17, '199999999999999', 'Admin, S.Kom', 'Admin', 'BMN dan Sarpras', 'BMN dan Sarpras');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id_history` int(10) NOT NULL,
  `nip` varchar(50) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `nama_barang` varchar(52) NOT NULL,
  `nup` varchar(22) NOT NULL,
  `tipe` varchar(52) NOT NULL,
  `sn` varchar(8) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `keterangan` varchar(22) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `koor` varchar(65) NOT NULL,
  `jabatan` varchar(65) NOT NULL,
  `ruang` varchar(42) NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `tanggal_dikembalikan` date NOT NULL,
  `jumlah` varchar(5) NOT NULL,
  `peruntukan` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id_history`, `nip`, `kode_barang`, `nama_barang`, `nup`, `tipe`, `sn`, `tahun`, `keterangan`, `nama`, `koor`, `jabatan`, `ruang`, `tanggal_pinjam`, `tanggal_dikembalikan`, `jumlah`, `peruntukan`) VALUES
(1, '199999999999999', '3000000001', 'ALAT TESTER', '1', 'Mesin tester', '2122', '2022', 'Normal', 'Admin, S.Kom', 'BMN dan Sarpras', 'Admin', '', '2022-07-18', '2022-07-18', '1', '12 test et te te'),
(2, '199999999999999', '3100102002', 'Lap Top', '77', 'Dell Business Notebook Vostro 14 5468 Wi 10', '1ZTFXF2', '2017', 'Engsel Rusak', 'Admin, S.Kom', 'BMN dan Sarpras', 'Admin', '', '2022-07-18', '2022-07-18', '1', 'Rapat Kerja Pimpinan PTS LLDIKTI Wilayah VII');

-- --------------------------------------------------------

--
-- Table structure for table `pinjaman`
--

CREATE TABLE `pinjaman` (
  `id_peminjam` int(4) NOT NULL,
  `id_brg` int(4) NOT NULL,
  `nip` varchar(20) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jabatan` varchar(50) NOT NULL,
  `koor` varchar(50) NOT NULL,
  `ruang` varchar(42) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `nup` varchar(4) NOT NULL,
  `tipe` varchar(50) NOT NULL,
  `sn` varchar(12) NOT NULL,
  `tahun` varchar(4) NOT NULL,
  `keterangan` varchar(22) NOT NULL,
  `tanggal_surat` date NOT NULL DEFAULT current_timestamp(),
  `jumlah` int(4) NOT NULL,
  `peruntukan` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pinjaman`
--

INSERT INTO `pinjaman` (`id_peminjam`, `id_brg`, `nip`, `nama`, `jabatan`, `koor`, `ruang`, `kode_barang`, `nama_barang`, `nup`, `tipe`, `sn`, `tahun`, `keterangan`, `tanggal_surat`, `jumlah`, `peruntukan`) VALUES
(7, 1, '196407041987011001', 'dr. Ivan Rovian, M.Kp', 'Kepala Bagian Umum', 'Kepala Bagian Umum', '', '3100102002', 'Lap Top', '109', 'Lenovo V14 Gen2, i7,4G+8G, 1T+256G', '121212', '2019', '121212', '2022-07-18', 1, 'sdd');

-- --------------------------------------------------------

--
-- Table structure for table `t_batal`
--

CREATE TABLE `t_batal` (
  `id_batal` int(11) NOT NULL,
  `nip` varchar(18) NOT NULL,
  `kode_barang` varchar(18) NOT NULL,
  `nama` varchar(32) NOT NULL,
  `koor` varchar(55) NOT NULL,
  `jabatan` varchar(32) NOT NULL,
  `tipe` varchar(32) NOT NULL,
  `nama_barang` varchar(32) NOT NULL,
  `tanggal_surat` date NOT NULL,
  `tanggal_dibatalkan` date NOT NULL,
  `nup` varchar(6) NOT NULL,
  `jumlah` varchar(6) NOT NULL,
  `peruntukan` varchar(232) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t_batal`
--

INSERT INTO `t_batal` (`id_batal`, `nip`, `kode_barang`, `nama`, `koor`, `jabatan`, `tipe`, `nama_barang`, `tanggal_surat`, `tanggal_dibatalkan`, `nup`, `jumlah`, `peruntukan`) VALUES
(2, '196407041987011001', '3100102002', 'dr. Ivan Rovian, M.Kp', 'Kepala Bagian Umum', 'Kepala Bagian Umum', 'Lenovo V14 Gen2, i7,4G+8G, 1T+25', 'Lap Top', '0000-00-00', '2022-07-18', '109', '1', 'Tusi Kabag Umum'),
(3, '3578040405810004', '3100102002', 'As\'ari, S.Kom', 'BMN dan Sarpras', 'Teknisi', 'Dell Latitude 5290 (i5,4GB,1TB,W', 'Lap Top', '0000-00-00', '2022-07-18', '90', '1', 'Pengelolaan BMN, Pengelollan Server, Pembuatan Program, Network Adminstrator'),
(4, '196503141985032001', '3100102002', 'Ida Ayu Siti Hamidah, S.H.', 'Koordinator Kemahasiswaan', 'Koordinator Kemahasiswaan', 'Dell Business Notebook Vostro 14', 'Lap Top', '2022-07-17', '2022-07-18', '77', '1', 'Workshop Pengembangan Kurikulum Merdeka Belajar Kampus Merdeka bagi Perguruan Tinggi di Lingkungan LLDIKTI Wilayah VII'),
(5, '3578040405810004', '3000000001', 'As\'ari, S.Kom', 'BMN dan Sarpras', 'Teknisi', 'Mesin tester', 'ALAT TESTER', '2022-07-17', '2022-07-18', '1', '1', 'Rapat Kerja Pimpinan PTS LLDIKTI Wilayah VII');

-- --------------------------------------------------------

--
-- Table structure for table `t_image`
--

CREATE TABLE `t_image` (
  `id_img` varchar(3) NOT NULL,
  `id_brg` varchar(4) NOT NULL,
  `img1` varchar(42) NOT NULL,
  `img2` varchar(42) NOT NULL,
  `img3` varchar(42) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t_image`
--

INSERT INTO `t_image` (`id_img`, `id_brg`, `img1`, `img2`, `img3`) VALUES
('1', '', 'header.png', 'header', '');

-- --------------------------------------------------------

--
-- Table structure for table `t_jabatan`
--

CREATE TABLE `t_jabatan` (
  `id_jbt` int(3) NOT NULL,
  `jabatan` varchar(92) NOT NULL,
  `koor` varchar(92) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t_jabatan`
--

INSERT INTO `t_jabatan` (`id_jbt`, `jabatan`, `koor`) VALUES
(18, 'Kepala Bagian Umum', 'Kepala bagian Umum'),
(19, 'Koordinator Kepegawaian, dan Tata Laksana', 'Kepegawaian, dan Tata Laksana'),
(20, 'Koordinator Hukum, Humas, dan Kerjasama', 'Hukum, Humas, dan Kerjasama'),
(21, 'Koordinator Renggar dan pelaporan', 'Renggar dan Pelaporan'),
(22, 'Koordinator Keuangan', 'Keuangan'),
(23, 'Koordinator BMN dan Sarpras', 'BMN dan Sarpras'),
(24, 'Koordinator Tata Usaha dan Kearsipan', 'Tata Usaha dan Kearsipan'),
(25, 'Koordinator Kelembagaan dan Sistem Informasi Perguruan Tinggi', 'Kelembagaan dan Sistem Informasi Perguruan Tinggi'),
(26, 'Koordinator Kelembagaan dan Sistem Informasi Perguruan Tinggi Vokasi', 'Kelembagaan dan Sistem Informasi Perguruan Tinggi Vokasi'),
(27, 'Koordinator Akademik dan Risbang', 'Akademik dan Risbang'),
(28, 'Koordinator Kemahasiswaan', 'Kemahasiswaan'),
(29, 'Koordinator Layanan Ketenagaan', 'Layanan Ketenagaan'),
(30, 'Koordinator Sertifikasi dan Layanan Pendidik', 'Sertifikasi dan Mutu Pendidik'),
(33, 'Teknisi', 'BMN dan Sarpras'),
(34, 'Admin', 'BMN dan Sarpras');

-- --------------------------------------------------------

--
-- Table structure for table `t_ruang`
--

CREATE TABLE `t_ruang` (
  `id_ruang` int(11) NOT NULL,
  `kode_r` varchar(6) NOT NULL,
  `n_ruang` varchar(43) NOT NULL,
  `p_ruang` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t_ruang`
--

INSERT INTO `t_ruang` (`id_ruang`, `kode_r`, `n_ruang`, `p_ruang`) VALUES
(3, 'G.1.A', 'Pusat Informasi dan Layanan Terpadu', 'Dra. Ec. Yayuk Suci Rahayu, M.A.'),
(4, 'G.1.B', 'BMN dan Sarpras', 'Erdianto Setyo Wahyono, R., S.E.'),
(5, 'G.2.C', 'Kepala Bagian Umum', 'dr. Ivan Rovian, M.Kp');

-- --------------------------------------------------------

--
-- Table structure for table `t_tanda`
--

CREATE TABLE `t_tanda` (
  `id_tt` int(4) NOT NULL,
  `header` varchar(255) NOT NULL,
  `footer` varchar(52) NOT NULL,
  `jabatan` varchar(42) NOT NULL,
  `nama` varchar(42) NOT NULL,
  `nip` varchar(18) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `t_tanda`
--

INSERT INTO `t_tanda` (`id_tt`, `header`, `footer`, `jabatan`, `nama`, `nip`) VALUES
(1, 'Kepala Bagian Umum Lembaga Layanan Pendidikan Tinggi Wilayah VII, memberi izin penggunaan Barang Milik Negara kepada', 'Kepala Bagian Umum', 'Kepala bagian Umum', 'dr. Ivan Rovian, M.Kp', '1978111111'),
(2, 'Kepala Lembaga Layanan Pendidikan Tinggi Wilayah VII, memberi izin penggunaan Barang Milik Negara kepada', 'Kepala', 'kepala', 'Dr. Dyah Sawitri', '19670000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD UNIQUE KEY `id_admin` (`id_admin`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_brg`);

--
-- Indexes for table `barang2`
--
ALTER TABLE `barang2`
  ADD UNIQUE KEY `id_kode` (`id_kode`),
  ADD UNIQUE KEY `kode_barang` (`kode_barang`,`nama_barang`);

--
-- Indexes for table `datapegawai`
--
ALTER TABLE `datapegawai`
  ADD PRIMARY KEY (`id_peg`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD UNIQUE KEY `id_staff` (`id_history`);

--
-- Indexes for table `pinjaman`
--
ALTER TABLE `pinjaman`
  ADD PRIMARY KEY (`id_peminjam`);

--
-- Indexes for table `t_batal`
--
ALTER TABLE `t_batal`
  ADD PRIMARY KEY (`id_batal`);

--
-- Indexes for table `t_jabatan`
--
ALTER TABLE `t_jabatan`
  ADD PRIMARY KEY (`id_jbt`);

--
-- Indexes for table `t_ruang`
--
ALTER TABLE `t_ruang`
  ADD PRIMARY KEY (`id_ruang`);

--
-- Indexes for table `t_tanda`
--
ALTER TABLE `t_tanda`
  ADD PRIMARY KEY (`id_tt`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_brg` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `barang2`
--
ALTER TABLE `barang2`
  MODIFY `id_kode` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `datapegawai`
--
ALTER TABLE `datapegawai`
  MODIFY `id_peg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id_history` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pinjaman`
--
ALTER TABLE `pinjaman`
  MODIFY `id_peminjam` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `t_batal`
--
ALTER TABLE `t_batal`
  MODIFY `id_batal` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `t_jabatan`
--
ALTER TABLE `t_jabatan`
  MODIFY `id_jbt` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `t_ruang`
--
ALTER TABLE `t_ruang`
  MODIFY `id_ruang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `t_tanda`
--
ALTER TABLE `t_tanda`
  MODIFY `id_tt` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
