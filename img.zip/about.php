<div class="container">
	<div class="row">
		<div class="col-md-12">
			<div class="panel panel-default">
				<div class="panel panel-heading">Tentang Aplikasi</div>
				<div class="panel panel-body">
					<div class="box-header">
						<div class="box-body"> <h3 class="box-title">Aplikasi ini Diperuntukan untuk perekaman Ijin Pemakaian BMN, jika Ada Kesalahan Dalam Input data bisa hubungi admin.</h3>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>