  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Versi</b> 1.1.1
    </div>
    <strong>Aplikasi Ijin Pakai BMN LLDIKTI Wilayah VII<a href="http://lldikti7.kemdikbud.go.id">-Sistem Pendataan Pengelolaan BMN </a>.</strong>
  </footer>
