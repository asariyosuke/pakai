<section class="content">
    <?php
    if(!empty($_SESSION['msg'])){
        echo $_SESSION['msg'];
    }
    ?>

    <div class="box">
        <form >
            <div class="box-header">
                <h3 class="box-title">Data Riwayat Peminjaman</h3>
            </div>
            <div class="box-body">
                <input type="hidden" name="page"  value= "data-history" class="form-control">

                <!-- <input type="text" name="valueToSearch" placeholder="Value To Search"><br><br>-->
                <div>
                    <label>Tipe Pencarian:</label>
                    <select name="macam" class="form-control">
                        <option value="">--Pilih--</option>
                        <!--<option value="nip">NIP</option-->
                        <option value="nama">Nama</option>
                        <!--<option value="unit_kerja">Unit Kerja</option>-->
                        <option value="jabatan">Jabatan</option>
                        <option value="tipe">Tipe Barang</option>
                        <option value="kode_barang">Kode Jenis</option>
                        <option value="n_barang">Nama Barang</option>
                        <option value="tanggal_pinjam">Tanggal Pinjam</option>
                        <option value="tanggal_kembali">Tanggal Kembali</option>
                        <option value="nup">NUP</option>
                    </select>
                    <?php
                    /*                $sql = $config->query('select nib from barang');
                                    echo "<select name='nib'>";

                                    while ($row = mysqli_fetch_array($sql)){
                                        echo "<option value='". $row['nib'] ."'>" .  $row['nib'] . "</option>";
                                    }
                                    echo "</select>";
                      */              ?>
                </div>
                <div>
                    <label class="form">Nama Pencarian:</label>
                    <input type="text" name="valueToSearch" class="form-control" placeholder="Nama Barang">
                </div>
                <div class="input-group group-tongle">
                    <input type="submit" style="margin-top: 10px;" class="btn btn-default form-control" value="cari">
                </div>
            </div>
        </form>
    </div>
    <!-- /.box-header -->
    <div class="box">
    <div class="box-body">
        <div class="table-responsive">
            <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>No</th>
                    <th>Nama </th>
                    <th>Jabatan</th>
					<th>Kode Brg </th>
					<th>Nama Brg</th>
					<th>NUP</th>
					<th>Tipe Brg </th>
                    <th>Tanggal Pinjam</th>
                    <th>Tanggal Dikembalikan</th>
                    <th>Keterangan</th>
                </tr>
                </thead>
                <tbody>
                <?php
                //============================================Ini gunanya untuk membuka semua barang yang ada di database

                if(isset($_GET['valueToSearch'])) {
                    $valueToSearch = $_GET['valueToSearch'];
                    $macam = $_GET['macam'];
                    if ($_GET['valueToSearch'] == "" || $_GET['valueToSearch']== null){
                        $sql = $config->query('select * from history');
                    }else {
                        $sql = $config->query('select * FROM history where ' . $macam . ' = "' . $valueToSearch . '"');
                    }
                }
                else{
                    $sql = $config->query('select * from history');
                }
                $i=0;
                while($row = $config->select($sql)){
                $i++;
                ?>
                <tr>
                    <td><?php echo $i;?></td>
                    <td><?php echo $row['nama'] ?></td>
                    <td><?php echo $row['jabatan'] ?></td>
					<td><?php echo $row['kode_barang'] ?></td>
					<td><?php echo $row['nama_barang'] ?></td>
                    <td><?php echo $row['nup'] ?></td>
					<td><?php echo $row['tipe'] ?></td>
                    <td><?php echo $row['tanggal_pinjam'] ?></td>
                    <td><?php echo $row['tanggal_dikembalikan'] ?></td>
                    <td><?php echo $row['keterangan'] ?></td>
                </tr>
        </div>


        <?php
        }
        ?>
        </tbody>
        </table>
    </div>

    <!-- /.box-body -->
    </div>
    <!-- /.box -->

</section>