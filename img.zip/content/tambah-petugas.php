<section class="content">
 <?php
 if(!empty($_SESSION['msg'])){
 echo $_SESSION['msg'];
 }
 ?>
<div class="table-responsive">
  <div class="container-fluid">
    <div class="col-md-2">
      <form id="form-tambah-petugas" action="<?php echo $config->site_url(); ?>process.php?act=add_petugas" method="post">
        <div class="input-group">
          <label class="form"><br></br><br></br> </label>
		</div>
		<div class="input-group">
          <label class="form">NIP:</label>
          <input type="text" name="nip" class="form-control" required
           minlength="9" >
        </div>
		<div class="input-group">
          <label class="form">Nama Lengkap:</label>
          <input type="text" name="nama" class="form-control" required>
        </div>
		<div class="input-group">
			<label>Jabatan:</label>
			<input list="jabatan" name="jabatan" class="form-control" required>
               <?php
               $sql2 = $config->query('select * from t_jabatan');
               echo "<datalist id='jabatan'> ";
               while ($row2 = mysqli_fetch_array($sql2))
			   		{echo "<option value='". $row2['jabatan'] ."'>" .  $row2['jabatan'] . "</option>";}
               echo "</datalist>";
               ?>
        </div>
		<div class="input-group">
			<label>Pokja:</label>
			<input list="koor" name="koor" class="form-control" required>
               <?php
               $sql2 = $config->query('select * from t_jabatan');
               echo "<datalist id='koor'> ";
               while ($row2 = mysqli_fetch_array($sql2))
			   		{echo "<option value='". $row2['koor'] ."'>" .  $row2['koor'] . "</option>";}
               echo "</datalist>";
               ?>
        </div>
		<div class="input-group">
			<label>Ruangan:</label>
			<input list="n_ruang" name="ruang" class="form-control" required>
               <?php
               $sql2 = $config->query('select * from t_ruang');
               echo "<datalist id='n_ruang'> ";
               while ($row2 = mysqli_fetch_array($sql2))
			   		{echo "<option value='". $row2['n_ruang'] ."'>" .  $row2['kode_r'] . "</option>";}
               echo "</datalist>";
               ?>
        </div>
		<div class="input-group">
          <label class="form"><br></br></label>
		</div>
        <div class="input-group group-tongle">
          <input type="submit" class="btn btn-success" value="Tambahkan"/>
        </div>
      </form>
    </div>

    <div class="box-body">
    <div class="col-md-10">
      <div class="table-responsive">
        <table id="example1" class="table table-bordered table-striped">
         <h1>Data Pegawai Peminjam </h1>
        <thead>
          <tr>
            <th>No</th>
            <th>NIP</th>
			<th>Nama Lengkap</th>
			<th>Jabatan</th>
			<th>Pokja</th>
			<th>Ruangan</th>
            <th>Action</th>
          </tr>
        </thead>
            <tbody>
          <?php
          $i=0;
          $sql = $config->query('select * from datapegawai');
          while($row = $config->select($sql)){
            $i++;?>
            <tr>
              <td><?php echo $i;?></td>
              <td><?php echo $row['nip'];?></td>
			  <td><?php echo $row['nama'];?></td>
			  <td><?php echo $row['jabatan'];?></td>
			  <td><?php echo $row['koor'];?></td>
			  <td><?php echo $row['ruang'];?></td>
              <td>
                <div class="btn-group">
  				<button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
    			Action
  				</button>
  				<div class="dropdown-menu">
    				<a class="dropdown-item" href="#"data-toggle="modal" data-target="#editPetugas<?php echo $row['id_peg']; ?>">Edit</a>
    			<div class="dropdown-divider"></div>
    				<a class="dropdown-item" href="<?php echo $config->site_url().'process.php?act=delete_data_petugas&id='.$row['id_peg']; ?>">Hapus</a>
				<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="#"data-toggle="modal" data-target="#fotoBarang<?php echo $row['id_img']; ?>">Foto</a>
				</div>
				</td>
              </tr>
          <div id="editPetugas<?php echo $row['id_peg']; ?>" class="modal modal-success fade" role="dialog">
           <div class="modal-dialog">
            <div class="modal-content">
             <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal">&times;</button>
               <h4 class="modal-title">Edit Data </h4>
             </div>
              <div class="modal-body">
               <form id="form-tambah-petugas" action="<?php echo $config->site_url(); ?>process.php?act=update_data_petugas" method="post" onsubmit="confirm('yakin ingin edit data?');">
                <div class="input-group">
                 <label class= "form">NIP:</label>
                 <input type="text" name="nip" class="form-control" value="<?php echo $row['nip']; ?>" required>
                </div>
                <div class="input-group">
                <label class="form">Nama Lengkap:</label>
                <input type="text" name="nama" class="form-control"value="<?php echo $row['nama']; ?>" required>
                </div>
                <div class="form-group">
                	<label>Jabatan:</label>
						<input list="jabatan" name="jabatan" class="form-control" required>
                        	<?php
                            $sql2 = $config->query('select * from t_jabatan');
                            echo "<datalist id='jabatan'> ";
                            while ($row2 = mysqli_fetch_array($sql2)){
                            echo "<option value='". $row2['jabatan'] ."'>" .  $row2['jabatan'] . "</option>";
	                            }
                            echo "</datalist>";
                            ?>              
				</div>
				<div class="form-group">
                	<label>Pokja :</label>
						<input list="koor" name="koor" class="form-control" required>
                        	<?php
                            $sql2 = $config->query('select * from t_jabatan');
                            echo "<datalist id='koor'> ";
                            while ($row2 = mysqli_fetch_array($sql3)){
                            echo "<option value='". $row2['koor'] ."'>" .  $row2['koor'] . "</option>";
	                            }
                            echo "</datalist>";
                            ?>              
				</div>
				<div class="input-group">
			<label>Ruangan:</label>
			<input list="n_ruang" name="ruang" class="form-control" required>
               <?php
               $sql2 = $config->query('select * from t_ruang');
               echo "<datalist id='n_ruang'> ";
               while ($row2 = mysqli_fetch_array($sql2))
			   		{echo "<option value='". $row2['n_ruang'] ."'>" .  $row2['kode_r'] . "</option>";}
               echo "</datalist>";
               ?>
        </div>
               <div class="input-group">
               <div class="input-group group-tongle">
               		<input type="hidden" name="id" value="<?php echo $row['id_peg']; ?>"></input>
                    <input type="submit" style="margin-top: 10px;" class="btn btn-default form-control" value="Edit">
                              </div>

                              <div class="modal-footer">
                                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                              </div>
                      </div>
                  </form>
              </div>

                      <?php
                    }
                    ?>
            </tbody>
                  </table>
                </div>
              </div>
    </div>
 </div></div>
            </section>