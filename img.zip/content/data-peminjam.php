<section class="content">
<?php 
  if(!empty($_SESSION['msg'])){
    echo $_SESSION['msg'];
  }
?>
<?php
	$tgl=date('d-m-y');
    ?>
     <div class="box">
     	<form>
        <input type="hidden" name="page"  value= "data-peminjam" class="form-control">
     	<div class="box-header">
      	<h3 class="box-title">Buat Surat Ijin Pakai</h3>
      </div>
      	<div class="box-body">
        	<div>
            <label class="form">Nomor Induk Pegawai:</label>
            <input list="nip" name="valueToSearch" class="form-control" placeholder="Masukkan Nomor Induk Pegawai" required>
            <?php
            	$sql = $config->query('select nip, nama from datapegawai');
                echo "<datalist id='nip'> ";
                while ($row = mysqli_fetch_array($sql)){
                echo "<option value='". $row['nip'] ."'>" .  $row['nama'] . "</option>";
                }
                echo "</datalist>";
             ?>
            <label class="form">Kode Barang:</label>
            <input list="kode" name="valueToSearch3" class="form-control" placeholder="Masukkan Kode Barang" required>
            <?php
            	$sql2 = $config->query('select kode_barang, nama_barang from barang2');
                echo "<datalist id='kode'> ";
                while ($row2 = mysqli_fetch_array($sql2)){
                echo "<option value='". $row2['kode_barang'] ."'>" . "(".$row2['nama_barang'] .")</option>";
                }
                echo "</datalist>";
            ?>
            <label class="form">NUP:</label>
            <input type="text" name="valueToSearch2" class="form-control" placeholder="Masukkan Nomor NUP" required>
            <input type="submit" style="margin-top: 10px;" class="btn btn-default form-control" value="Cari">
       	</div>
       </form>
            <?php
            //============================================Ini gunanya untuk membuka semua barang yang ada di database
            $id_brg="";
			$nama="";
            $unitkerja ="";
            $jabatan="";
            $tipe="";
			$sn="";
            $tersedia="";

            if(isset($_GET['valueToSearch'])) {
            	$valueToSearch = $_GET['valueToSearch'];
                $valueToSearch2= $_GET['valueToSearch2'];
                $valueToSearch3= $_GET['valueToSearch3'];
                $sql = $config->query('select * FROM datapegawai where nip = "' . $valueToSearch . '"');
                $sql2 = $config->query('select * FROM barang where nup = "' . $valueToSearch2 . '"and kode_barang ="'.$valueToSearch3.'"');
                $row = $config->select($sql);
                $row2 = $config->select($sql2);
                $nama	=$row['nama'];
                $unitkerja =$row['koor'];
                $jabatan =$row['jabatan'];
                $tipe = $row2['tipe'];
				$sn = $row2['sn'];
				$tahun = $row2['tahun'];
				$kt = $row2['keterangan'];
                $kode = $row2['kode_barang'];
                $n_barang= $row2 ['nama_barang'];
				$nup	= $row2 ['nup'];
				$id_brg	= $row2 ['id_brg'];
                (int)$tersedia = $row2 ['ketersediaan'];
            }
            else{
                  $nama="";
                  $unitkerja ="";
                  $jabatan="";
                  $tipe="";
				  $sn="";
                  $n_barang="";
                  $jumlah="";
            }
            if((int)$tersedia==0 && isset($_GET['valueToSearch'])){
                echo '<div class="alert alert-error">Stock habis atau barang yang dicari tidak ditemukan. 
                        <b> Tolong periksa data yang diisi.</b> </div>';
                echo '<script>window.location.href="'.$config->site_url().'index.php?page=data-peminjam</script>';

            }
            elseif ((int)$tersedia>0) {
            ?>
			
                <form id="form-data-barang" action="<?php echo $config->site_url(); ?>process.php?act=add_data_pinjaman"
                      method="post">
                    <input type="hidden" value="<?php echo $valueToSearch ?>" name="nip">
                    <input type="hidden" value="<?php echo $valueToSearch2 ?>" name="nup">
                    <input type="hidden" value="<?php echo $nama ?>" name="nama">
                    <input type="hidden" value="<?php echo $kode ?>" name="kode_barang">
                    <input type="hidden" value="<?php echo $unitkerja ?>" name="koor">
                    <input type="hidden" value="<?php echo $jabatan ?>" name="jabatan">
                    <input type="hidden" value="<?php echo $tipe ?>" name="tipe">
					<input type="hidden" value="<?php echo $sn ?>" name="sn">
					<input type="hidden" value="<?php echo $tahun ?>" name="tahun">
					<input type="hidden" value="<?php echo $kt ?>" name="keterangan">
                    <input type="hidden" value="<?php echo $n_barang ?>" name="nama_barang">
					<input type="hidden" value="<?php echo $id_brg ?>" name="id_brg">
					<input type="hidden" value="<?php echo $nup ?>" name="nup">

                    <?php

                    ?>

                    <div>
                        <label class="form">Nama :</label>
                        <input type="text" value="<?php echo $nama ?>" name="nama" class="form-control"
                               placeholder="<?php echo $nama ?>" disabled>
                    </div>
					<div>
                        <label class="form">Jabatan:</label>
                        <input type="text" value="<?php echo $jabatan ?>" name="jabatan" class="form-control"
                               placeholder="<?php echo $jabatan ?>" disabled>
                    </div>
                    <div>
                        <label class="form">Ruang :</label>
                        <input type="text" value="<?php echo $unitkerja ?>" name="koor" class="form-control"
                               placeholder="<?php echo $unitkerja ?>" disabled>
                    </div>
                    
					 <div>
                        <label class="form">Nama Barang:</label>
                        <input type="text" value="<?php echo $n_barang ?>" name="nama_barang" class="form-control"
                               placeholder="<?php echo $n_barang ?>" disabled>
                    </div>
					<div>
                        <label class="form">NUP:</label>
                        <input type="text" value="<?php echo $nup ?>" name="nup" class="form-control"
                               placeholder="<?php echo $nup ?>" disabled>
                    </div>
                    <div>
                        <label class="form">Tipe Barang :</label>
                        <input type="text" value="<?php echo $tipe ?>" name="tipe" class="form-control"
                               placeholder="<?php echo $tipe ?>" disabled>
                    </div>
					<div>
                        <label class="form">Nomer Seri :</label>
                        <input type="text" value="<?php echo $sn ?>" name="sn" class="form-control"
                               placeholder="<?php echo $sn ?>" disabled>
                    </div>
					<div>
                        <label class="form">Tahun :</label>
                        <input type="text" value="<?php echo $tahun ?>" name="sn" class="form-control"
                               placeholder="<?php echo $tahun ?>" disabled>
                    </div>
					<div>
                        <label class="form">Keterangan :</label>
                        <input type="text" value="<?php echo $kt ?>" name="keterangan" class="form-control"
                               placeholder="<?php echo $kt ?>" disabled>
                    </div>
                  <div>
                        <label class="form">Peruntukan:</label>
                        <input type="text" name="peruntukan" class="form-control" required />
                  </div>
                  
                  <div class="input-group">
                        <label class="form">Jumlah Barang:</label>
                        <input type="number" class="form-control" name="jumlah" min="1" max="10" />
                  </div>


                    <div class="input-group group-tongle">
                        <tr>
                            <input type="submit" style="margin-top: 10px;" class="btn btn-default form-control"
                                   value="PROSES">
                        </tr>
                        <tr>
                            <input type="submit" style="margin-top: 10px;" class="btn btn-default form-control"
                                   onclick="http://localhost/pinjam/index.php?page=data-peminjam" value="BATAL">
                        </tr>
                    </div>
                    <div class="input-group group-tongle">

                    </div>
                </form>

                <?php
            }
              ?>
          </div>
            <!-- /.box-header -->


            <!-- /.box-body -->

          </div>
          <!-- /.box -->
</section>