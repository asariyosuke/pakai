<section class="content">
<?php
	if(!empty($_SESSION['msg'])){
	echo $_SESSION['msg'];}
?>
<div class="table-responsive">
  <div class="container-fluid">
    <div class="col-md-2">
      <form id="form-tambah-ruangan" action="<?php echo $config->site_url(); ?>process.php?act=add_ruangan" method="post">
      	<div class="input-group">
        	<label class="form"><br></br><br></br> </label>
		</div>
		<div class="input-group">
          <label class="form">Kode Ruang:</label>
          <input type="text" name="kode_r" class="form-control" required>
        </div>
		<div class="input-group">
          <label class="form">Nama Ruang:</label>
          <input type="text" name="n_ruang" class="form-control" required>
        </div>
					 <div class="input-group">
					<label>Penanggung Jawab:</label>
					<input list="nama" name="p_ruang" class="form-control" required>
               		<?php
               		$sql2 = $config->query('select * from datapegawai');
               		echo "<datalist id='nama'> ";
               		while ($row2 = mysqli_fetch_array($sql2))
			   		{echo "<option value='". $row2['nama'] ."'>" .  $row2['nip'] . "</option>";}
               		echo "</datalist>";
               		?>      
				  </div>
        <div class="input-group group-tongle">
          <input type="submit" class="btn btn-success" value="Tambahkan"/>
        </div>
      </form>
    </div>
    <div class="box-body">
    <div class="col-md-10">
      <div class="table-responsive">
        <table id="example1" class="table table-bordered table-striped">
         <h1>Daftar Nama Ruangan </h1>
        <thead>
          <tr>
            <th>No</th>
			<th>Kode Ruang</th>
			<th>Nama Ruang</th>
			<th>Penanggung Jawab</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $i=0;
          $sql = $config->query('select * from t_ruang');
          while($row = $config->select($sql)){
            $i++;?>
            <tr>
              <td><?php echo $i;?></td>
			  <td><?php echo $row['kode_r'];?></td>
			  <td><?php echo $row['n_ruang'];?></td>
			  <td><?php echo $row['p_ruang'];?></td>
              <td>
                <div class="btn-group">
  				<button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
    			Action
  				</button>
  				<div class="dropdown-menu">
    				<a class="dropdown-item" href="#"data-toggle="modal" data-target="#editRuangan<?php echo $row['id_ruang']; ?>">Edit</a>
    			<div class="dropdown-divider"></div>
    				<a class="dropdown-item" href="<?php echo $config->site_url().'process.php?act=delete_data_ruangan&id='.$row['id_ruang']; ?>">Hapus</a>
				<div class="dropdown-divider"></div>
  				</div></td>
              </tr>
          <div id="editRuangan<?php echo $row['id_ruang']; ?>" class="modal modal-success fade" role="dialog">
           <div class="modal-dialog">
            <div class="modal-content">
             <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal"></button>
               <h4 class="modal-title">Edit Data </h4>
         </div>
         <div class="modal-body">
				<form id="form-tambah-ruangan" action="<?php echo $config->site_url(); ?>process.php?act=update_data_ruangan" method="post" onsubmit="confirm('yakin ingin edit data?');">
				<div class="input-group">
                	<input type="hidden" name="id_ruang" class="form-control" value="<?php echo $row['id_ruang']; ?>" required>             
				</div>
				<div class="input-group">
					<label class="form">Kode Ruang:</label>
                    	<input type="text" name="kode_r" class="form-control" value="<?php echo $row['kode_r']; ?>" required>             
				 </div>
				<div class="input-group">
					<label class="form">Nama Ruang:</label>
                    	<input type="text" name="n_ruang" class="form-control" value="<?php echo $row['n_ruang']; ?>" required>             
				  </div>
				 <div class="input-group">
					<label>Penanggung Jawab:</label>
					<input list="nama" name="p_ruang" class="form-control" required>
               		<?php
               		$sql2 = $config->query('select * from datapegawai');
               		echo "<datalist id='nama'> ";
               		while ($row2 = mysqli_fetch_array($sql2))
			   		{echo "<option value='". $row2['nama'] ."'>" .  $row2['nip'] . "</option>";}
               		echo "</datalist>";
               		?>      
				  </div>
                <div class="input-group group-tongle">
                <input type="hidden" name="id" value="<?php echo $row['id_ruang']; ?>"></input>
                <input type="submit" style="margin-top: 10px;" class="btn btn-default form-control" value="Edit">
                </div>
                	<div class="modal-footer">
                   	<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                 </div> 
			    </form>
             </div>
             <?php
                    }
                    ?>
            </tbody>
            </table>
                </div>
              </div>
    </div>
 </div></div>
            </section>