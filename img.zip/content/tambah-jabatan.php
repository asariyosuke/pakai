<section class="content">
<?php
	if(!empty($_SESSION['msg'])){
	echo $_SESSION['msg'];}
?>
<div class="table-responsive">
  <div class="container-fluid">
    <div class="col-md-2">
      <form id="form-tambah-petugas" action="<?php echo $config->site_url(); ?>process.php?act=add_jabatan" method="post">
      	<div class="input-group">
        	<label class="form"><br></br><br></br> </label>
		</div>
		<div class="input-group">
          <label class="form">Nama Jabatan:</label>
          <input type="text" name="jabatan" class="form-control" required>
        </div>
		<div class="input-group">
          <label class="form">Pokja/Bagian:</label>
          <input type="text" name="koor" class="form-control" required>
        </div>
        <div class="input-group group-tongle">
          <input type="submit" class="btn btn-success" value="Tambahkan"/>
        </div>
      </form>
    </div>
    <div class="box-body">
    <div class="col-md-10">
      <div class="table-responsive">
        <table id="example1" class="table table-bordered table-striped">
         <h1>Daftar Jabatan </h1>
        <thead>
          <tr>
            <th>No</th>
			<th>Nama Jabatan</th>
			<th>Nama Pokja/Bagian</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $i=0;
          $sql = $config->query('select * from t_jabatan');
          while($row = $config->select($sql)){
            $i++;?>
            <tr>
              <td><?php echo $i;?></td>
			  <td><?php echo $row['jabatan'];?></td>
			  <td><?php echo $row['koor'];?></td>
              <td>
                <div class="btn-group">
  				<button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
    			Action
  				</button>
  				<div class="dropdown-menu">
    				<a class="dropdown-item" href="#"data-toggle="modal" data-target="#editJabatan<?php echo $row['id_jbt']; ?>">Edit</a>
    			<div class="dropdown-divider"></div>
    				<a class="dropdown-item" href="<?php echo $config->site_url().'process.php?act=delete_data_jabatan&id='.$row['id_jbt']; ?>">Hapus</a>
				<div class="dropdown-divider"></div>
  				</div>
				</td>
              </tr>
          <div id="editJabatan<?php echo $row['id_jbt']; ?>" class="modal modal-success fade" role="dialog">
           <div class="modal-dialog">
            <div class="modal-content">
             <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal"></button>
               <h4 class="modal-title">Edit Data </h4>
         </div>
         <div class="modal-body">
				<form id="form-tambah-jabatan" action="<?php echo $config->site_url(); ?>process.php?act=update_data_jabatan" method="post" onsubmit="confirm('yakin ingin edit data?');">
				<div class="input-group">
                	<input type="hidden" name="id_jbt" class="form-control" value="<?php echo $row['id_jbt']; ?>" required>             
				</div>
				<div class="input-group">
					<label class="form">Jabatan:</label>
                    	<input type="text" name="jabatan" class="form-control" value="<?php echo $row['jabatan']; ?>" required>             
				  </div>
				 <div class="input-group">
					<label class="form">Pokja/Bagian:</label>
                    	<input type="text" name="koor" class="form-control" value="<?php echo $row['koor']; ?>" required>             
				  </div>
                <div class="input-group group-tongle">
                <input type="hidden" name="id" value="<?php echo $row['id_jbt']; ?>"></input>
                <input type="submit" style="margin-top: 10px;" class="btn btn-default form-control" value="Edit">
                </div>
                	<div class="modal-footer">
                   	<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                 </div> 
			    </form>
             </div>
             <?php
                    }
                    ?>
            </tbody>
            </table>
                </div>
              </div>
    </div>
 </div></div>
            </section>