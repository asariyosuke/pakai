<?php /* Created by ELGA RIDLO SINATRIYA
         18-Oktober-2018
         email address elgaridlosinatriya@gmail.com
  */ ?>


<section class="content">
<?php
  if(!empty($_SESSION['msg'])){
    echo $_SESSION['msg'];
  }
?>

<div class="box">
	<form >
    	<div class="box-header">
        	<h3 class="box-title">Data Barang</h3>
        </div>
        	        <!-- /.box-header -->
    <div class="box">
        <div class="box-body">
            <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    
                    <tr>
                        <th>No</th>
                        <th>NUP</th>
                        <th>Tipe Barang</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Tahun Perolehan </th>
                        <th>Kelompok Barang</th>
                        <th>Ketersediaan</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
<?php
//============================================Ini gunanya untuk membuka semua barang yang ada di database

if(isset($_GET['valueToSearch'])) {
    $valueToSearch = $_GET['valueToSearch'];
    $macam = $_GET['macam'];
    if ($_GET['valueToSearch'] == "" || $_GET['valueToSearch']== null){
        $sql = $config->query('select * from barang');
    }else {
        $sql = $config->query('select * FROM barang where ' . $macam . ' LIKE "%' . $valueToSearch . '%"');
        }
    }
else{
        $sql = $config->query('select * from barang');
    }
  $i=0;
  while($row = $config->select($sql)){
  $i++;
  
?>
                <tr>
                  <td><?php echo $i;?></td
                  ><td><?php echo $row['nup'] ?></td>
                  <td><?php echo $row['tipe'] ?></td>
                  <td><?php echo $row['kode_barang'] ?></td>
                  <td><?php echo $row['nama_barang'] ?></td>
                  <td><?php echo $row['tahun'] ?></td>
                  <td><?php echo $row['kelompok'] ?></td>
                  <td><?php echo $row['ketersediaan'] ?></td>
                  <td>

                   
                    
                  </td>
                </tr>
                 


<?php
  }
?>

            </tbody> </table>
          </div>
</div>
         <!-- /.box-body -->

          <!-- /.box -->