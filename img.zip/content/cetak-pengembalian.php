
<div class="box-body">
<h3 class="box-title">CETAK FORM PENGEMBALIAN BARANG</h3>
<form method="get" target="_blank" action="cetak/cetakpengembalian.php">
<!-- Date -->
    <div class="box">
        <div class="box-body">
            <div class="form-group">
                <label class="form">NIP:</label>
                <div class="input-group" >
                    <div class="input-group-addon">
                        <i class="fa fa-angle-down"></i>
                    </div>
                    <input type="text" name="nip" list="nip" name="valueToSearch" class="form-control" placeholder="Masukkan Nomor Induk Pegawai" required>
			<?php
                   $sql3 = $config->query('select nip, nama from datapegawai');
                   echo "<datalist id='nip'> ";
                   while ($row3 = mysqli_fetch_array($sql3)){
                   echo "<option value='". $row3['nip'] ."'>" .  $row3['nama'] . "</option>";
                   }
                   echo "</datalist>";
                   ?>
        </div>
                </div>
                <!-- /.input group -->
            </div>
            <!-- /.form group -->

            <div class="form-group">
                <label>TANGGAL PEMNGEMBALAN:</label>

                <div class="input-group date">
                    <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <input type="text" name="end" class="form-control" id="endDate">
                </div>
                <!-- /.input group -->
            </div>
            <!-- /.form group -->

            <button type="submit" class="btn btn-sm btn-info"><i class="fa fa-print"></i> Cetak</button>
         Pastikan barang telah dikembalikan melalui menu Data Peminjaman atau lihat di Riwayat Pengembalian </div>
    </div>
</form>
</div>