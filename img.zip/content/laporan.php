<div class="container-fluid">
<div class="box">
	<div class="box-header">
		<h3 class="box-title">Pilih Data Yang Ingin Anda Cetak</h3>
	</div> 
	<button onClick="window.location='index.php?page=cetak-pengembalian'" style="margin-bottom: 12px; width: 200px; height: 200px;" type="button" class="btn btn-primary btn-print" ><i class="fa fa-print"></i> Cetak Data Pengembalian</button>
		<button onClick="window.location='index.php?page=cetak-peminjaman'" style="margin-bottom: 12px; width: 200px; height: 200px;" class="btn btn-primary btn-print" ><i class="fa fa-print"></i> Cetak Data Peminjaman</button>
		<button onClick="window.location='index.php?page=cetak-peminjaman2'" style="margin-bottom: 12px; width: 200px; height: 200px;" class="btn btn-primary btn-print" ><i class="fa fa-print"></i> Cetak Data Peminjaman 2</button>
</div>
</div>
