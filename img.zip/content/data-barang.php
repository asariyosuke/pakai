
<section class="content">
<?php
  if(!empty($_SESSION['msg'])){
    echo $_SESSION['msg'];
  }
?>

<div class="box">
	<form >
    	<div class="box-header">
        	<h3 class="box-title">Data Barang</h3>
        </div>
        	<div class="box-body">
             	<input type="hidden" name="page"  value= "data-barang" class="form-control">
            		<div>
                		<label>Tipe Pencarian :</label>
                		<select name="macam" class="form-control">
                    	<option value="">--Pilih--</option>
                    	<option value="nup">NUP</option>
                    	<option value="tipe">Tipe Barang</option>
                    	<option value="kode_barang">Kode Barang</option>
                    	<option value="nama_barang">Nama Barang</option>
                    	<option value="tahun">Tahun Perolehan</option>
              		</div>
                <!-- <input type="text" name="valueToSearch" placeholder="Value To Search"><br><br>-->
            		<div>
                	<label class="form">Nama Pencarian:</label>
                	<input type="text" name="valueToSearch" class="form-control" placeholder="Nama Barang">
            		</div>
            		<div class="input-group group-tongle">
                	<input type="submit" style="margin-top: 10px;" class="btn btn-default form-control" value="cari">
            		</div>
        </form>
        </div>
        <!-- /.box-header -->
    <div class="box">
        <div class="box-body">
            <div class="table-responsive">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <button style="margin-bottom: 12px;" type="button" class="btn btn-success btn-add" data-toggle="modal" data-target="#addBarang"><i class="fa fa-plus"></i> Tambah Data Barang</button>
                    <tr>
                        <th width="3">No</th>
						<th width="32">Kode Barang</th>
                        <th width="150">Nama Barang</th>
						<th width="32">NUP</th>
						<th width="220">Tipe Barang </th>
						<th width="32">Nomor Seri</th>
						<th width="56">Tahun </th>
                        <th width="51">Keterangan</th>
                        <th width="39">Stok</th>
                        <th width="51">Action</th>
                    </tr>
                    </thead>
                    <tbody>
<?php
//============================================Ini gunanya untuk membuka semua barang yang ada di database

if(isset($_GET['valueToSearch'])) {
    $valueToSearch = $_GET['valueToSearch'];
    $macam = $_GET['macam'];
    if ($_GET['valueToSearch'] == "" || $_GET['valueToSearch']== null){
        $sql = $config->query('select * from barang');
    }else {
        $sql = $config->query('select * FROM barang where ' . $macam . ' LIKE "%' . $valueToSearch . '%"');
        }
    }
else{
        $sql = $config->query('select * from barang');
    }
  $i=0;
  while($row = $config->select($sql)){
  $i++;
  
?>
                <tr>
                  <td><?php echo $i;?></td>
				  <td><?php echo $row['kode_barang'] ?></td>
				  <td><?php echo $row['nama_barang'] ?></td>
				  <td><?php echo $row['nup'] ?></td>
				  <td><?php echo $row['tipe'] ?></td>
				  <td><?php echo $row['sn'] ?></td>              
                  <td><?php echo $row['tahun'] ?></td>
                  <td><?php echo $row['keterangan'] ?></td>
                  <td><?php echo $row['ketersediaan'] ?></td>
                  <td>
				  <!-- Example single danger button -->
				<div class="btn-group">
  				<button type="button" class="btn btn-danger dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
    			Action
  				</button>
  				<div class="dropdown-menu">
    				<a class="dropdown-item" href="#"data-toggle="modal" data-target="#editBarang<?php echo $row['id_brg']; ?>">Edit</a>
    			<div class="dropdown-divider"></div>
    				<a class="dropdown-item" href="<?php echo $config->site_url().'process.php?act=delete_data_barang&id='.$row['id_brg']; ?>">Hapus</a>
				<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="#"data-toggle="modal" data-target="#fotoBarang<?php echo $row['id_brg']; ?>">Foto</a>
  				</div>
				</div>
                  </td>
				  <td>
					<div id="fotoBarang <?php echo $row['id_brg']; ?>" class="modal modal-success fade" role="dialog">
                      <div class="modal-dialog">
                      	<div class="modal-content">
                      		<div class="modal-header">
                      		<button type="button" class="close" data-dismiss="modal">&times;</button>
                       		<h4 class="modal-title">Tambah Foto </h4>
                      		</div>
                        		<div class="modal-body">
                        			<form id="form-data-barang" action="<?php echo $config->site_url(); ?>process.php?act=update_data_barang" method="post" onsubmit="confirm('yakin ingin edit data?');">
									<div class="input-group">
                            			<input type="hidden" name="id_brg" class="form-control" value="<?php echo $row['id_brg']; ?>" required>             
									</div>
									<div class="input-group">
                            			<label class="form">Kode Barang:</label>
                            			<input type="text" name="kode_barang" class="form-control" value="<?php echo $row['kode_barang']; ?>" required>
                        			</div>
                        			<div class="input-group">
                        				<label class="form">NUP:</label>
                            			<input type="text" name="nup" class="form-control" value="<?php echo $row['nup']; ?>" required>
                         			</div>
						 			<div class="input-group">
                            			<label class="form">Nama Barang:</label>
                            			<input type="text" name="nama_barang" class="form-control" value="<?php echo $row['nama_barang']; ?>" required>
                          			</div> 
                          			<div class="input-group">
                            			<label class="form">Tipe Barang:</label>
                            			<input type="text" name="tipe" class="form-control" value="<?php echo $row['tipe']; ?>" required>
                          			</div>
						            <div class="input-group group-tongle">
                            			<input type="hidden" name="id" value="<?php echo $row['id_brg']; ?>">
                            			<input type="submit" style="margin-top: 10px;" class="btn btn-default form-control" value="Edit">
                          			</div>
                        			</form>
                        		</div>
                        		<div class="modal-footer">
                        			<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        		</div>
                      		</div>
						</div>
						</div>
				  </td>
                </tr>
                 <div id="editBarang<?php echo $row['id_brg']; ?>" class="modal modal-success fade" role="dialog">
                      <div class="modal-dialog">
                      <div class="modal-content">
                      <div class="modal-header">
                      	<button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Edit Data Barang </h4>
                      </div>
                        <div class="modal-body">
                        <form id="form-data-barang" action="<?php echo $config->site_url(); ?>process.php?act=update_data_barang" method="post" onsubmit="confirm('yakin ingin edit data?');">
						<div class="input-group">
                            <input type="hidden" name="id_brg" class="form-control" value="<?php echo $row['id_brg']; ?>" required>             
						</div>
						<div class="input-group">
                            <label class="form">Kode Barang:</label>
                            <input type="text" name="kode_barang" class="form-control" value="<?php echo $row['kode_barang']; ?>" required>
                        </div>
                        <div class="input-group">
                        	<label class="form">NUP:</label>
                            <input type="text" name="nup" class="form-control" value="<?php echo $row['nup']; ?>" required>
                         </div>
						 <div class="input-group">
                            <label class="form">Nama Barang:</label>
                            <input type="text" name="nama_barang" class="form-control" value="<?php echo $row['nama_barang']; ?>" required>
                          </div> 
                          <div class="input-group">
                            <label class="form">Tipe Barang:</label>
                            <input type="text" name="tipe" class="form-control" value="<?php echo $row['tipe']; ?>" required>
                          </div>
						  <div class="input-group">
                            <label class="form">Nomer Seri:</label>
                            <input type="text" name="sn" class="form-control" value="<?php echo $row['sn']; ?>" required>
                          </div>                      
						  <div class="input-group">
                            <label class="form">Tahun Perolehan:</label>
                            <input type="text" name="tahun" class="form-control"value="<?php echo $row['tahun']; ?>" required>
                          </div>
                          <div class="form-group">
                            <label>Keterangan:</label>
                            <input type="text" name="keterangan" class="form-control"value="<?php echo $row['keterangan']; ?>" required>
                          </div>
                          <div class="input-group">
                            <label class="form">Ketersediaan:</label>
							<div align="left">
                            <input type="number" width="1" name="ketersediaan" class="form-control" min="0" max="1" value="<?php echo $row['ketersediaan']; ?>" required>
                          </div>
                          <div class="input-group group-tongle">
                            <input type="hidden" name="id" value="<?php echo $row['id_brg']; ?>">
                            <input type="submit" style="margin-top: 10px;" class="btn btn-default form-control" value="Edit">
                          </div>
                        </form>
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                      </div>
                </div>

<?php
  }
?>

            </tbody> </table>
          </div>
    </div>
         <!-- /.box-body -->

          <!-- /.box -->


                 <div id="addBarang" class="modal modal-success fade" role="dialog">
                 	<div class="modal-dialog">
                    	<div class="modal-content">
                        <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Tambah Data Barang</h4>
                        </div>
                        <div class="modal-body">
                        <form id="form-data-barang" action="<?php echo $config->site_url(); ?>process.php?act=add_data_barang" method="post">		   
						<div>
						<?php 
							$sql = $config->query('select * FROM barang');
            						$id_brg=1;
           							while($row = $config->select($sql))
  									$id_brg++;
										?>                        
						<input type="hidden" value="<?php echo $id_brg ?>" name="id_brg" class="form-control" disabled>
						</div>
						<div class="input-group">
                            <label class="form">Kode Barang -NUP:</label>
                            <?php
                  				$sql1 = $config->query('select * from barang2');
                   				echo "<datalist id='kode'> ";
                   				while ($row2 = mysqli_fetch_array($sql1)){
                   				echo "<option value='". $row2['kode_barang'] ."'>" .  $row2['kode_barang'] . "(" .  $row2['nama_barang'] .")</option>";}
                   				echo "</datalist>";
                   			?>
                          	<table width="199" cellpadding="2">
                              <tr>
                                <th width="109" scope="col"><div align="left">
                                  <input list="kode" width="100" name="kode_barang" class="form-control" required="required" />
                                </div></th>
                                <th width="74" scope="col"><div align="left">
                                  <input type="text" width="10" name="nup" class="form-control" required="required" />
                                </div></th>
                              </tr>
                            </table>
						</div>
						<div class="input-group">
                                <label class="form">Nama Barang:</label>
                                <div align="left">
                                  <input list="nama_barang" width="120" name="nama_barang" class="form-control" required>
                                  <?php
                                	$sql2 = $config->query('select * from barang2');
                                	echo "<datalist id='nama_barang'> ";
                                	while ($row2 = mysqli_fetch_array($sql2)){
                                    echo "<option value='". $row2['nama_barang'] ."'>" .  $row2['nama_barang'] . "</option>";}
                                	echo "</datalist>";
                                ?>
                                    </div>
						</div>	
                          <div class="input-group">
                            <label class="form">Tipe Barang:</label>
                            <div align="left">
                              <input type="text" width="100" name="tipe" class="form-control" required>
                              </div>
                          </div>
						  <div class="input-group">
                            <label class="form">Nomer Seri:</label>
                            <div align="left">
                              <input type="text" width="100" name="sn" class="form-control" required>
                              </div>
						  </div>
						  <div class="input-group">
                            <label class="form">Tahun Perolehan:</label>
                            <div align="left">
                              <input type="text" width="100" name="tahun" class="form-control" required>
                              </div>
						  </div>
                          <div class="form-group">
                            <label>Keterangan:</label>
                            <div align="left">
                              <input type="text" name="keterangan" class="form-control" required>
                              </div>
                          </div>
                          <div class="input-group">
                             <label class="form">Jumlah Barang:</label>
                             <div align="left">
                               <input type="number" width="1"name="ketersediaan" min="0" max="1"class="form-control" required>
                                </div>
                          </div>
                          <div class="input-group group-tongle">
                            <input type="submit" style="margin-top: 10px;" class="btn btn-default form-control" value="Tambahkan">
                          </div>
                        </form>
                        </div>
                        <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>
                      </div>
                </div>