_INDEX_STRINGS = {"COMMON": {"H1": "お疲れ様でした!",
"ENABLED": "ASUSTOR NAS で Web サーバーが有効になりました。",
"INFO": "NAS で Web サイトをホストするには、<br/>[ <strong>Web</strong> ] 共有フォルダーに Web ページをアップロードします。",
"LINK": "ここをクリックし、ADM に入ります。"
}
};