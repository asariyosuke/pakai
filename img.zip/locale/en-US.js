/* _INDEX_STRINGS */
_INDEX_STRINGS = {
	"COMMON": {
		"H1": "Congratulations!",
		"ENABLED": "You have successfully enabled the Web server on your ASUSTOR NAS.",
		"INFO": "To begin hosting your website on the NAS,<br/>simply upload your web pages to the [ <strong>Web</strong> ] shared folder.",
		"LINK": "Click here to enter ADM"
	}
};