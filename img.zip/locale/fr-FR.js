_INDEX_STRINGS = {"COMMON": {"H1": "Félicitations !",
"ENABLED": "Vous avez active avec succès le serveur Web sur votre NAS ASUSTOR.",
"INFO": "Pour commencer l’hébergement de votre site Web sur le NAS,<br/>chargez simplement vos pages Web dans le dossier partagé[ <strong>Web</strong> ].",
"LINK": "Cliquer ici pour entrer dans ADM"
}
};