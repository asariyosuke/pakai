_INDEX_STRINGS = {"COMMON": {"H1": "Gratulálunk!",
"ENABLED": "A Webszervert sikeresen engedélyezte az Asustor NAS-on.",
"INFO": "A weblapja NAS-on való host-olásának elkezdéséhez<br/>egyszerűen töltse fel a weboldalakat a [ <strong>Web</strong> ] megosztott mappába.",
"LINK": "Az ADM-be való belépéshez kattintson ide"
}
};