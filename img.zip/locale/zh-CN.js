_INDEX_STRINGS = {"COMMON": {"H1": "恭喜！",
"ENABLED": "您已经成功地启用 ASUSTOR NAS 上的网站服务器功能。",
"INFO": "如果您需要在 NAS 上架设您的网站，<br/>只要将您的档案上传至 NAS的 [ <strong>Web</strong> ] 共享文件夹中就可以喽！",
"LINK": "点击这里进入ADM"
}
};