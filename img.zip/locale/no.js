_INDEX_STRINGS = {"COMMON": {"H1": "Gratulerer!",
"ENABLED": "Du har nå aktivert web-serveren på ASUSTOR NAS.",
"INFO": "Du kan begynne med å drifte nettstedet på NAS-en<br/>ved å laste opp web-sider til den delte mappen [ <strong>Web</strong> ].",
"LINK": "Klikk her for å åpne ADM"
}
};