_INDEX_STRINGS = {"COMMON": {"H1": "Gratulacje!",
"ENABLED": "Serwer sieci Web został pomyślnie uaktywniony na serwerze ASUSTOR NAS.",
"INFO": "Aby rozpocząć hosting witryny na serwerze NAS,<br/>prześlij strony sieci Web do folderu udostępnionego [ <strong>Web</strong> ].",
"LINK": "Kliknij tutaj, aby przejść do systemu ADM"
}
};