_INDEX_STRINGS = {"COMMON": {"H1": "Tebrikler!",
"ENABLED": "Web sunucusunu ASUSTOR NAS cihazınız üzerinde başarıyla etkinleştirdiniz.",
"INFO": "Web sitenizi NAS üzerinde barındırmaya başlamak için,<br/>tek yapmanız gereken web sayfalarınızı [<strong>Web</strong>] paylaşılan klasörü içine yüklemektir.",
"LINK": "ADM (ASUSTOR Data Master)’a girmek için buraya tıklayın"
}
};