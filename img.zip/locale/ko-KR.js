_INDEX_STRINGS = {"COMMON": {"H1": "축하합니다!",
"ENABLED": "ASUSTOR NAS에서 웹 서버를 성공적으로 활성화했습니다.",
"INFO": "NAS에서 웹 사이트 호스팅을 시작하려면,<br/>웹 페이지를 [<strong>웹</strong>] 공유 폴더에 업로드하면 됩니다.",
"LINK": "ADM를 시작하려면 여기를 클릭하십시오."
}
};