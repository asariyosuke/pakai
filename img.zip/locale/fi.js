_INDEX_STRINGS = {"COMMON": {"H1": "Onnittelut!",
"ENABLED": "Verkkopalvelimen käyttöönotto ASUSTOR NAS -palvelimellasi onnistui.",
"INFO": "Aloittaaksesi web-sivustosi isännöinnin NAS-palvelimella riittää,<br/>kun siirrät web-sivusi jaettuun [<strong>Web</strong>] -kansioon.",
"LINK": "Napsauta tässä siirtyäksesi ADM:ään."
}
};