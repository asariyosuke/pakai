_INDEX_STRINGS = {"COMMON": {"H1": "Grattis!",
"ENABLED": "Du har aktiverat webbservern på din ASUSTOR NAS.",
"INFO": "För att börja använda din NAS som värd för din webbplats,<br/>för du bara över dina webbsidor till den delade [ <strong>Web</strong> ]-mappen.",
"LINK": "Klicka här för att öppna ADM"
}
};