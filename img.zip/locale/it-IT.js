_INDEX_STRINGS = {"COMMON": {"H1": "Congratulazioni!",
"ENABLED": "Hai correttamente abilitato il server web su ASUSTOR NAS.",
"INFO": "PEr iniziare ad ospitare il sito web sul NAS,<br/>basta caricare le pagine web sulla cartella condivisa [<strong>Web</strong>].",
"LINK": "Fare clic qui per accedere ad ADM"
}
};