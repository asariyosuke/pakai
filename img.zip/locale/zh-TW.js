_INDEX_STRINGS = {"COMMON": {"H1": "恭喜！",
"ENABLED": "您已經成功地啟用 ASUSTOR NAS 上的網站伺服器功能。",
"INFO": "如果您需要在 NAS 上架設您的網站，<br/>只要將您的檔案上傳至 NAS 的 [ <strong>Web</strong> ] 共用資料夾中就可以嘍！",
"LINK": "點擊這裡進入ADM"
}
};