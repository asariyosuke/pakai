_INDEX_STRINGS = {"COMMON": {"H1": "Tillykke!",
"ENABLED": "Web-serveren er nu slået til på din ASUSTOR NAS.",
"INFO": "For at starte din webside på din NAS,<br/>skal du blot uploade siderne til den delte mappe [ <strong>Web</strong> ].",
"LINK": "Klik er for, at åbne ADM"
}
};