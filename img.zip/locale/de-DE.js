_INDEX_STRINGS = {"COMMON": {"H1": "Herzlichen Glückwunsch!",
"ENABLED": "Sie haben den Webserver an Ihrem ASUSTOR NAS erfolgreich aktiviert.",
"INFO": "Damit Sie mit dem Hosten Ihrer Webseite auf dem NAS beginnen können, <br/>müssen Sie lediglich Ihre Webseiten in den [ <strong>Web</strong> ]-Freigabeordner hochladen.",
"LINK": "Zum Aufrufen von ADM hier klicken"
}
};