_INDEX_STRINGS = {"COMMON": {"H1": "Gefeliciteerd!",
"ENABLED": "U heeft de Web server op uw ASUSTOR NAS succesvol ingeschakeld",
"INFO": "Om te beginnen met het hosten van uw website op de NAS,<br/>upload u uw web pagina's naar de gedeelde [<strong>Web</strong>] map",
"LINK": "Klik hier om ADM te openen"
}
};