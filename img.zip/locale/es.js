_INDEX_STRINGS = {"COMMON": {"H1": "¡Enhorabuena!",
"ENABLED": "El servidor Web se ha habilitado correctamente en su ASUSTOR NAS.",
"INFO": "Para comenzar a hospedar su sitio Web en su NAS,<br/>simplemente cargue sus páginas Web en la carpeta compartida [<strong>Web</strong>].",
"LINK": "Haga clic aquí para entrar en ADM"
}
};