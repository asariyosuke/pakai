_INDEX_STRINGS = {"COMMON": {"H1": "Gratulujeme!",
"ENABLED": "Úspěšně jste povolili Webový server na Vašem Asustor NAS",
"INFO": "Pro započetí hostingu Všeho webu na NAS serveru<br/>jednoduše nahrajte webové stránky na  sdílenou složku  [ <strong>Web</strong> ].",
"LINK": "Klikněte zde pro vstup do ADM"
}
};