<?php
  session_start();
  include('../config/config.php');
  $config = new config();
?>
<script type="text/javascript">
<!--
window.print();
//-->
</script>

<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<style type="text/css">
<!--
.style1 {font-size: 10px}
.style2 {
	font-family: Times, serif;
	font-size: 14pt;
}
-->
</style>
<div class="container-fluid">
  <div class="box">
    <div class="box-header">
    </div>
    <!-- /.box-header -->

      <div>
         
          <table width="100%">
              <tr>
                  
                  <!--<div class="col-md-2">
-->         <td width="90%" align="center">
			<img src="img/header.png" alt="" width="922" height="175" />
                      <h4 class="style2" style="text-align: center;">Berita Acara Pengembalian Barang Milik Negara (BMN)</h4>
                      </td>

              </tr>
          </table>
<!--?php
function TanggalIndonesia($date) {
    $date = date('Y-m-d',strtotime($date));
    if($date == '0000-00-00')
        return 'Tanggal Kosong';
 
    $tgl = substr($date, 8, 2);
    $bln = substr($date, 5, 2);
    $thn = substr($date, 0, 4);
 
    switch ($bln) {
        case 1 : {
                $bln = 'Januari';
            }break;
        case 2 : {
                $bln = 'Februari';
            }break;
        case 3 : {
                $bln = 'Maret';
            }break;
        case 4 : {
                $bln = 'April';
            }break;
        case 5 : {
                $bln = 'Mei';
            }break;
        case 6 : {
                $bln = "Juni";
            }break;
        case 7 : {
                $bln = 'Juli';
            }break;
        case 8 : {
                $bln = 'Agustus';
            }break;
        case 9 : {
                $bln = 'September';
            }break;
        case 10 : {
                $bln = 'Oktober';
            }break;
        case 11 : {
                $bln = 'November';
            }break;
        case 12 : {
                $bln = 'Desember';
            }break;
        default: {
                $bln = 'UnKnown';
            }break;
    }
 
    $hari = date('N', strtotime($date));
    switch ($hari) {
        case 0 : {
                $hari = 'Minggu';
            }break;
        case 1 : {
                $hari = 'Senin';
            }break;
        case 2 : {
                $hari = 'Selasa';
            }break;
        case 3 : {
                $hari = 'Rabu';
            }break;
        case 4 : {
                $hari = 'Kamis';
            }break;
        case 5 : {
                $hari = "Jum'at";
            }break;
        case 6 : {
                $hari = 'Sabtu';
            }break;
        default: {
                $hari = 'UnKnown';
            }break;
    }
 
    $tanggalIndonesia = "".$hari.",".$tgl . " " . $bln . " " . $thn;
    return $tanggalIndonesia;
}
?-->
<?php
 //Fungsi Konversi nilai angka menjadi nilai huruf
 function penyebut($nilai) {
  $nilai = abs($nilai);
  $huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
  $temp = "";
  if ($nilai < 12) {
   $temp = " ". $huruf[$nilai];
  } else if ($nilai <20) {
   $temp = penyebut($nilai - 10). " belas";
  } else if ($nilai < 100) {
   $temp = penyebut($nilai/10)." puluh". penyebut($nilai % 10);
  } else if ($nilai < 200) {
   $temp = " seratus" . penyebut($nilai - 100);
  } else if ($nilai < 1000) {
   $temp = penyebut($nilai/100) . " ratus" . penyebut($nilai % 100);
  } else if ($nilai < 2000) {
   $temp = " seribu" . penyebut($nilai - 1000);
  } else if ($nilai < 1000000) {
   $temp = penyebut($nilai/1000) . " ribu" . penyebut($nilai % 1000);
  } else if ($nilai < 1000000000) {
   $temp = penyebut($nilai/1000000) . " juta" . penyebut($nilai % 1000000);
  } else if ($nilai < 1000000000000) {
   $temp = penyebut($nilai/1000000000) . " milyar" . penyebut(fmod($nilai,1000000000));
  } else if ($nilai < 1000000000000000) {
   $temp = penyebut($nilai/1000000000000) . " trilyun" . penyebut(fmod($nilai,1000000000000));
  }   
  return $temp;
 }

 function terbilang($nilai) {
  if($nilai<0) {
   $hasil = "minus ". trim(penyebut($nilai));
  } else {
   $hasil = trim(penyebut($nilai));
  }       
  return $hasil;
 }
 function hri_aja($hari_a){
   $hari = getHari(substr($hari_a,0,2));
   return $hari;  
 }
  //Fungsi ambil tanggal aja
 function tgl_aja($tgl_a){
   $tanggal = substr($tgl_a,8,2);
   return $tanggal;  
 }

 //Fungsi Ambil bulan aja
 function bln_aja($bulan_a){
   $bulan = getBulan(substr($bulan_a,5,2));
   return $bulan;  
 } 

 //Fungsi Ambil tahun aja
 function thn_aja($thn){
   $tahun = substr($thn,0,4);
   return $tahun;  
 }

 //Fungsi konversi tanggal bulan dan tahun ke dalam bahasa indonesia
 function tgl_indo($tgl){
   //$hari = getHari(substr(tgl,0,4)); 
   $tanggal = substr($tgl,8,2);
   $bulan = getBulan(substr($tgl,5,2));
   $tahun = substr($tgl,0,4);
   return $hari.' '.$tanggal.' '.$bulan.' '.$tahun;  
 }
 function getHari($hri){
    switch ($hri){
     case 1:
      return "minggu";
      break;
     case 2:
      return "senin";
      break;
     case 3:
      return "selasa";
      break;
     case 4:
      return "rabu";
      break;
     case 5:
      return "kamis";
      break;
     case 6:
      return "jumat";
      break;
     case 7:
      return "sabtu";
      default;
	  return "UnKnown";
	}}
  
   //Fungsi konversi nama bulan ke dalam bahasa indonesia
 function getBulan($bln){
    switch ($bln){
     case 1:
      return "Januari";
      break;
     case 2:
      return "Februari";
      break;
     case 3:
      return "Maret";
      break;
     case 4:
      return "April";
      break;
     case 5:
      return "Mei";
      break;
     case 6:
      return "Juni";
      break;
     case 7:
      return "Juli";
      break;
     case 8:
      return "Agustus";
      break;
     case 9:
      return "September";
      break;
     case 10:
      return "Oktober";
      break;
     case 11:
      return "November";
      break;
     case 12:
      return "Desember";
      break;
    }
   }
?>

<?php
$nip = $_GET['nip'];
$end = $_GET['end'];
$tgl=date('Y-m-d');
$i = 0;
$sql = $config->query("SELECT b.nama,b.nip,b.jabatan, a.tanggal_dikembalikan, a.peruntukan,
a.kode_barang,a.nama_barang,a.nup,a.tipe,a.jumlah
 from history a join datapegawai b on a.nip = b.nip where a.tanggal_dikembalikan = '$end' and b.nip = '$nip' ");
$row = $config->select($sql);
$peruntukan=$row['peruntukan'];
$nama =$row['nama'];
$nip=$row['nip'];
$jabatan=$row['jabatan'];
//$tp=$row['tanggal_pinjam'];
//$tk=$row['tanggal_kembali'];
$tdk=$row['tanggal_dikembalikan'];
?>
          <!--h5 style="text-align: left;"><u>FORM PENGEMBALIAN BARANG</u></h5-->
          <!--<hr style="border: 1px solid #000000;">
-->
              <?php while($row = $config->select($sql)){

                  if($row['peruntukan'] != $peruntukan){
                      msg("failed","Failed!","Gagal mencetak , terdapat peruntukan yang berbeda");
                      echo '<script>window.location.href="'.$config->site_url().'index.php?page=cetak-peminjaman"</script>';                  }
                  $peruntukan=$row['peruntukan'];
              } $row = $config->select($sql);?>

              <div style="text-align: justify;">
              <pre>
    Dalam rangka penatausahaan Barang Milik Negara (BMN) pada hari ini saya :
Nama                : <?php echo $nama?>

NIP                 : <?php echo $nip ?>

Jabatan     	    : <?php echo $jabatan ?>

Tanggal Dikembalikan: <?php echo hri_aja(date ($tdk))?> <?php echo terbilang(tgl_aja ($tdk))?> <?php echo bln_aja(date ($tdk))?> <?php echo terbilang(thn_aja ($tdk))?><br>
Mengembalikan barang yang saya pinjam sebagaimana tersebut dibawah ini.
              </pre> </div>

              <h5 style="text-align: left;">DATA BARANG YANG DIKEMBALIKAN</h5>
              <table id="example1" class="table table-bordered table-striped" width="100%">
                  <thead>
                  <tr align="center">
                      <th>No</th>
                      <th>Kode Barang</th>
                      <th>Nama Barang</th>
                      <th>NUP</th>
                      <th>Merk/Type</th>
                      <th>SN</th>
                      <th width="30%">Keterangan</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  //$end = $_GET['end'];
                  $i = 0;
                  $sql2 = $config->query("SELECT * from history where tanggal_dikembalikan= '$tdk' and peruntukan='$peruntukan'");
                  while($row2 = $config->select($sql2)){
                  $i++; ?>
                  <tr>
                      <td><font size="2"><?php echo $i;?></font></td>
                      <td><font size="2"><?php echo $row2['kode_barang'] ?></font></td>
                      <td><font size="2"><?php echo $row2['nama_barang'] ?></font></td>
                      <td><font size="2"><?php echo $row2['nup'] ?></font></td>
                      <td><font size="2"><?php echo $row2['tipe'] ?></font></td>
                      <td><font size="2"><?php echo $row2['sn'] ?></font></td>
                      <td><font size="2"><?php //echo $row['peruntukan'] ?></font></td>
                      <?php
                      }
                      ?></tr>
                  </tbody>
              </table>
	    <div style="text-align: justify;"><!--?php echo $jabatan1?--><!--?php echo $unit?-->
            <table width="705" cellpadding="2">
              <tr>
                <td width="319" height="49" valign="top"><div align="center">
                  <p>Yang Mengembalikan <br />
                  </p>
                  <p>ttd</p>
                  </p>
                    <?php echo $nama?><br />
                    NIP <?php echo $nip ?></p>
                </div></td>
                <td width="9" valign="top">&nbsp;</td>
                <td width="355" valign="top">&nbsp;</td>
              </tr>
              <tr>
                
                
              </tr>
            </table>
            <p><em>Telah diperiksa dan diterima dalam keadaan baik, dan cukup satuan maupun jumlahnya: </em></p>
            <table width="784" cellpadding="2">
              <tr>
                <td width="316" height="49" valign="top"><div align="center">
                  <p class="style1">Yang Menyerahkan </p>
                  <p class="style1">&nbsp;</p>
                  <p><span class="style1">_______________</span><br />
                    <br />
                  </p>
                </div></td>
				<?php
   $user = $_SESSION['session_login']; $prev = $_SESSION['level'];
   $result = $config->query('select * from '.$prev.' where username="'.$user.'"');
   $row = $config->select($result);                
?>
                <td width="216" valign="top">&nbsp;</td>
                <td width="212"><span class="style1">Petugas Inventaris,
			    <br />
			    <br />
			    <br />
			    <br />
			    <?php echo $row['nama'];?> </br>
                </span></td>
                <p style="float: left">&nbsp;</p><td width="12"></td>
				
              </tr>
			  
              <tr> </tr>
            </table>
            <p>&nbsp;</p>
        </div>
    </div>
  </div>
  </div>