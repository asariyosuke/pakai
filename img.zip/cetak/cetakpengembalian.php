<?php
  session_start();
  include('../config/config.php');
  $config = new config();
?>
	<script type="text/javascript">
	<!--
	window.print();
	//-->
	</script>

<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<style type="text/css">
<!--
.style1 {font-size: 10px}
.style2 {
	font-family: Times, serif;
	font-size: 14pt;
}
-->
</style>
<div class="container-fluid">
  <div class="box">
    <div class="box-header">
    </div>
    <!-- /.box-header -->

      <div>
         
          <table width="100%">
              <tr>
                  
                  <!--<div class="col-md-2">
-->         <td width="90%" align="center">
			<img src="img/header.png" alt="" width="922" height="131" />
                      <h4 class="style2" style="text-align: center;">Berita Acara Pengembalian Barang Milik Negara (BMN)</h4>
                      </td>

              </tr>
          </table>
 <?php
function TanggalIndonesia($date) {
    $date = date('Y-m-d',strtotime($date));
    if($date == '0000-00-00')
        return 'Tanggal Kosong';
    $tgl = substr($date, 8, 2);
    $bln = substr($date, 5, 2);
    $thn = substr($date, 0, 4);
 
    switch ($bln) {
        case 1 : {
                $bln = 'januari';
            }break;
        case 2 : {
                $bln = 'februari';
            }break;
        case 3 : {
                $bln = 'maret';
            }break;
        case 4 : {
                $bln = 'april';
            }break;
        case 5 : {
                $bln = 'mei';
            }break;
        case 6 : {
                $bln = "juni";
            }break;
        case 7 : {
                $bln = 'juli';
            }break;
        case 8 : {
                $bln = 'agustus';
            }break;
        case 9 : {
                $bln = 'september';
            }break;
        case 10 : {
                $bln = 'oktober';
            }break;
        case 11 : {
                $bln = 'november';
            }break;
        case 12 : {
                $bln = 'desember';
            }break;
        default: {
                $bln = 'UnKnown';
            }break;
    }
 
    $hari = date('N', strtotime($date));
    switch ($hari) {
        case 0 : {
                $hari = 'minggu';
            }break;
        case 1 : {
                $hari = 'senin';
            }break;
        case 2 : {
                $hari = 'selasa';
            }break;
        case 3 : {
                $hari = 'rabu';
            }break;
        case 4 : {
                $hari = 'kamis';
            }break;
        case 5 : {
                $hari = "jum'at";
            }break;
        case 6 : {
                $hari = 'sabtu';
            }break;
        default: {
                $hari = 'UnKnown';
            }break;
    } 
    $tanggalIndonesia = " ".$hari;
    return $tanggalIndonesia;
}
?>

  <?php
 //Fungsi Konversi nilai angka menjadi nilai huruf
 function penyebut($nilai) {
  $nilai = abs($nilai);
  $huruf = array("", "satu", "dua", "tiga", "empat", "lima", "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
  $temp = "";
  if ($nilai < 12) {
   $temp = " ". $huruf[$nilai];
  } else if ($nilai <20) {
   $temp = penyebut($nilai - 10). " belas";
  } else if ($nilai < 100) {
   $temp = penyebut($nilai/10)."puluh". penyebut($nilai % 10);
  } else if ($nilai < 200) {
   $temp = " seratus" . penyebut($nilai - 100);
  } else if ($nilai < 1000) {
   $temp = penyebut($nilai/100) . " ratus" . penyebut($nilai % 100);
  } else if ($nilai < 2000) {
   $temp = " seribu" . penyebut($nilai - 1000);
  } else if ($nilai < 1000000) {
   $temp = penyebut($nilai/1000) . "ribu" . penyebut($nilai % 1000);
  } else if ($nilai < 1000000000) {
   $temp = penyebut($nilai/1000000) . " juta" . penyebut($nilai % 1000000);
  } else if ($nilai < 1000000000000) {
   $temp = penyebut($nilai/1000000000) . " milyar" . penyebut(fmod($nilai,1000000000));
  } else if ($nilai < 1000000000000000) {
   $temp = penyebut($nilai/1000000000000) . " trilyun" . penyebut(fmod($nilai,1000000000000));
  }   
  return $temp;
 }

  function terbilang($nilai) {
  if($nilai<0) {
   $hasil = "minus ". trim(penyebut($nilai));
  } else {
   $hasil = trim(penyebut($nilai));
  }       
  return $hasil;
 }
  //Fungsi ambil tanggal aja
 function tgl_aja($tgl_a){
   $tanggal = substr($tgl_a,8,2);
   return $tanggal;  
 }

 //Fungsi Ambil bulan aja
 function bln_aja($bulan_a){
   $bulan = getBulan(substr($bulan_a,5,2));
   //$bulan = getBulan('01');
   return $bulan;  
 } 

 //Fungsi Ambil tahun aja
 function thn_aja($thn){
   $tahun = substr($thn,0,4);
   return $tahun;  
 }

 //Fungsi konversi tanggal bulan dan tahun ke dalam bahasa indonesia
 function tgl_indo($tgl){
   $hari = getHari(substr($tgl)); 
   $tanggal = substr($tgl,8,2);
   $bulan = getBulan(substr($tgl,5,2));
   $tahun = substr($tgl,0,4);
   return $hari.' '.$tanggal.' '.$bulan.' '.$tahun;  
 }
  
   //Fungsi konversi nama bulan ke dalam bahasa indonesia
 function getBulan($bln){
    switch ($bln){
     case 01:
      return "januari";
      break;
     case 02:
      return "pebruari";
      break;
     case 03:
      return "maret";
      break;
     case 04:
      return "april";
      break;
     case 05:
      return "mei";
      break;
     case 06:
      return "juni";
      break;
     case 07:
      return "juli";
      break;
     case 8:
      return "agustus";
      break;
     case 9:
      return "september";
      break;
     case 10:
      return "oktober";
      break;
     case 11:
      return "november";
      break;
     case 12:
      return "desember";
      break;
    }
   }
?>
            
  <?php
$nip = $_GET['nip'];
$end = $_GET['end'];
//$tgl=date('Y-m-d');
$i = 0;
$sql = $config->query("SELECT b.nama, b.nip, b.jabatan, b.koor, a.tanggal_dikembalikan, a.ruang,
a.kode_barang,a.nama_barang,a.nup,a.tipe,a.jumlah
 from history a join datapegawai b on a.nip = b.nip where a.tanggal_dikembalikan = '$end' and b.nip = '$nip' ");
$row = $config->select($sql);
$ruang=$row['ruang'];
$nama =$row['nama'];
$nip=$row['nip'];
$jabatan=$row['jabatan'];
$koor=$row['koor'];
$tdk=$row['tanggal_dikembalikan'];
?>
            <?php while($row = $config->select($sql)){
                  if($row['ruang'] != $ruang){
                      msg("failed","Failed!","Gagal mencetak , terdapat ruangan yang berbeda");
                      echo '<script>window.location.href="'.$config->site_url().'index.php?page=cetak-peminjaman"</script>';                  }
                  $ruang=$row['ruang'];
              } $row = $config->select($sql);?>
		    </p>
          <p>Pada Hari ini <?= TanggalIndonesia(date($tdk)) ?> tanggal <?php echo terbilang(tgl_aja($tdk,8,2))?> bulan <?php echo getBulan(substr($tdk,5,2))?> tahun <?php echo terbilang(thn_aja($tdk,0,4))?>   dengan ini saya mengembalikan Barang Milik Negara yang saya pergunakan tersebut  dibawah ini :</p>
    <div style="text-align: justify;"></div>

              <table id="example1" class="table table-bordered table-striped" width="100%">
                  <thead>
                  <tr align="center">
                      <th width="6%" class="style2"><h4>No</h4></th>
                      <th width="22%" class="style2"><h4>Nama Barang </h4></th>
                      <th width="16%" class="style2"><h4>Kode Barang </h4></th>
                      <th width="24%" class="style2"><h4>Merk/Type</h4></th>
                      <th width="6%" class="style2"><div align="center" class="style2">
                        <h4>SN</h4>
                      </div></th>
                      <th width="26%" class="style2"><h4>Keterangan</h4></th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  $end = $_GET['end'];
                  $i = 0;
                  $sql2 = $config->query("SELECT * from history where tanggal_dikembalikan= '$tdk' and ruang='$ruang'");
                  while($row2 = $config->select($sql2)){
                  $i++; ?>
                  <tr>
                      <td><font size="2"><?php echo $i;?></font></td>
                      <td><font size="2"><?php echo $row2['nama_barang'] ?></font></td>
                      <td><font size="2"><?php echo $row2['kode_barang'] ?>-<?php echo $row2['nup'] ?></font></td>
                      <td><font size="2"><?php echo $row2['tipe'] ?></font></td>
                      <td><div align="center"><font size="2"><?php echo $row2['sn'] ?></font></div></td>
                      <td><font size="2"><?php //echo $row['peruntukan'] ?></font></td>
                      <?php
                      }
                      ?></tr>
                  </tbody>
        </table>
        <p>Pihak Pertama (Yang Menyerahkan)</p>
	          <table width="705" cellpadding="2">
                <tr>
                  <td width="115" height="20" valign="top">Nama </td>
                  <td width="20" valign="top">:</td>
                  <td width="548" valign="top"><?php echo $nama?></td>
                </tr>
                <tr>
                  <td height="20" valign="top">NIP</td>
                  <td valign="top">:</td>
                  <td valign="top"><?php echo $nip ?></td>
                </tr>
                <tr>
                  <td height="20" valign="top">Jabatan </td>
                  <td valign="top">&nbsp;</td>
                  <td valign="top"><?php echo $jabatan ?></td>
                </tr>
                <tr>
                  <td height="20" valign="top"> Ruangan </td>
                  <td valign="top">&nbsp;</td>
                  <td valign="top">&nbsp;</td>
                </tr>
              </table>
	          <p><?php $jabatan1;
					if($koor=='Kepala Bagian Umum'){$jabatan1 = 'Kepala';
					?>
            	<?php }
             	else{ $jabatan1 = 'Koordinator BMN dan Sarpras' ?>
                <?php   }
                              $sql3 = $config->query("SELECT * from datapegawai where jabatan = '$jabatan1'");
							  $row3 = $config->select($sql3);
                              $namaketua = $row3['nama'];
                              $nipketua = $row3['nip'];
                   ?></p>
	          <p>Pihak Kedua (Yang Menerima)</p>
	          <table width="705" cellpadding="2">
                <tr>
                  <td width="115" height="20" valign="top">Nama </td>
                  <td width="20" valign="top">:</td>
                  <td width="548" valign="top"><?php echo $namaketua?></td>
                </tr>
                <tr>
                  <td height="20" valign="top">NIP</td>
                  <td valign="top">:</td>
                  <td valign="top"><?php echo $nipketua ?></td>
                </tr>
                <tr>
                  <td height="20" valign="top">Jabatan </td>
                  <td valign="top">&nbsp;</td>
                  <td valign="top"><?php echo $jabatan1 ?></td>
                </tr>
              </table>
			  <br />
	          <p>Demikian Berita Acara ini dibuat sebagai dasar pencatatan BMN dalam Daftar Ruang;</p>
			  <br />
	          <table width="705" cellpadding="2">
                <tr>
                  <td width="319" height="49" valign="top"><div align="center">PIHAK PERTAMA<br />
                      <?php echo $jabatan?> <br />
                          <br />
                          <br />
                          <br />
                          <?php echo $nama?><br />
                    NIP <?php echo $nip ?></div></td>
                  <td width="9" valign="top">&nbsp;</td>
                  <td width="355" valign="top"><div align="center">PIHAK KEDUA<br />
                      <?php echo $jabatan1?><br />
                          <br />
                          <br />
                          <br />
                          <?php echo $namaketua?><br />
                    NIP<?php echo $nipketua ?> </div></td>
                </tr>
              </table>
	          <table width="705" cellpadding="2">
	  <p><?php $tahu;
					if($koor=='Kepala Bagian Umum'){$tahu = ' ';
					?>
            	<?php }
             	else{ $tahu = 'Kepala' ?>
                <?php   }
                              $sql3 = $config->query("SELECT * from datapegawai where jabatan = '$tahu'");
							  $row3 = $config->select($sql3);
                              $namatahu = $row3['nama'];
                              $niptahu = $row3['nip'];
                   ?></p>
                <tr>
                  <td width="113" height="20" valign="top">&nbsp;</td>
                  <td width="404" valign="top"><div align="center">Mengetahui</div></td>
                  <td width="166" valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td height="20" valign="top">&nbsp;</td>
                  <td valign="top"><div align="center"><?php echo $tahu ?>, </div></td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td height="20" valign="top">&nbsp;</td>
                  <td valign="top">&nbsp;</td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td height="20" valign="top">&nbsp;</td>
			
                  <td valign="top"><div align="center"></div></td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td height="20" valign="top">&nbsp;</td>
                  <td valign="top"><div align="center"><?php echo $namatahu ?></div></td>
                  <td valign="top">&nbsp;</td>
                </tr>
                <tr>
                  <td height="20" valign="top">&nbsp;</td>
                  <td valign="top"><div align="center">NIP<?php echo $niptahu ?></div></td>
                  <td valign="top">&nbsp;</td>
                </tr>
              </table>
	          <p align="center">&nbsp;</p>
	          <p>&nbsp;</p>
      </div>
  </div>
  </div>