<?php
	session_start();
	include('../config/config.php');
	$config = new config();
?>
<script type="text/javascript">
	<!--
	window.print();
	//-->
	</script>
<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<style type="text/css">
	<!--
.style10 {font-family: Times New Roman, serif; font-size: 14pt; }
.style12 {font-family: Times, serif}
.style14 {font-family: Times, serif; font-size: 12pt; }
.style23 {font-size: 12pt}
.style24 {font-family: "Times New Roman"; font-size: 12pt; }
.style32 {font-family: Times New Roman, serif; font-size: 16pt; font-weight: bold; }
.style41 {font-size: 14pt}
	-->
</style>
<script type="text/JavaScript">
<!--
function MM_swapImgRestore() { //v3.0
  var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
}

function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_swapImage() { //v3.0
  var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
   if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
}
//-->
</script>
  <div class="box">
  <class box width="80%">
    <!--div class="box-header"></div-->
    <!-- /.box-header -->
      <div class="style24">
          <table width="99%" align="center">
          <tr>
<?php
$nip = $_GET['nip'];
$end = $_GET['end'];
$i = 0;
$sql = $config->query("SELECT b.id_peg, b.nama, b.nip, b.jabatan, b.unit_kerja, a.id_peminjam, a.tanggal_surat, a.peruntukan,
a.kode_barang,a.nama_barang,a.nup,a.tipe,a.jumlah, a.sn, a.tahun, a.keterangan
 from pinjaman a join datapegawai b on a.nip = b.nip where a.tanggal_surat = '$end' and b.nip = '$nip' ");
$row = $config->select($sql);
$peruntukan=$row['peruntukan'];
$id_peg =$row['id_peg'];
$nama =$row['nama'];
$id_peminjam=$row['id_peminjam'];
$nip=$row['nip'];
$jabatan=$row['jabatan'];
$unit=$row['unit_kerja'];
$ts=$row['tanggal_surat'];
$nama_barang=$row['nama_barang'];
$kode_barang=$row['kode_barang'];
$nup=$row['nup'];
$tipe=$row['tipe'];
$sn=$row['sn'];
$tahun=$row['tahun'];
$keterangan=$row['keterangan'];
//$tk=$row['tanggal_kembali'];

?>
	
	<td width="90%" align="center">
	 <img src="img/header.png" alt="" width="1077" height="189" />
    	<h1 class="h3" style="text-align: center;">Surat Ijin Penggunaan Barang Milik Negara (BMN)</h1>
    	<p>
    	  <?php
		function TanggalIndonesia($date) {
    	$date = date('Y-m-d',strtotime($date));
    	if($date == '0000-00-00')
        return 'Tanggal Kosong';
    	$tgl = substr($date, 8, 2);
    	$bln = substr($date, 5, 2);
    	$thn = substr($date, 0, 4);
    	switch ($bln) {
        	case 1 : {
                $bln = 'Januari';
            	}break;
        	case 2 : {
                $bln = 'Februari';
            	}break;
        	case 3 : {
                $bln = 'Maret';
            	}break;
        	case 4 : {
                $bln = 'April';
            	}break;
        	case 5 : {
                $bln = 'Mei';
            	}break;
        	case 6 : {
                $bln = "Juni";
            	}break;
        	case 7 : {
                $bln = 'Juli';
            	}break;
        	case 8 : {
                $bln = 'Agustus';
            	}break;
        	case 9 : {
                $bln = 'September';
            	}break;
        	case 10 : {
                $bln = 'Oktober';
            	}break;
        	case 11 : {
                $bln = 'November';
            	}break;
        	case 12 : {
                $bln = 'Desember';
            	}break;
        	default: {
                $bln = 'UnKnown';
            	}break; }
 
    	$hari = date('N', strtotime($date));
    	switch ($hari) {
        	case 0 : {
                $hari = 'minggu';
            	}break;
        	case 1 : {
                $hari = 'senin';
            	}break;
        	case 2 : {
                $hari = 'selasa';
            	}break;
        	case 3 : {
                $hari = 'rabu';
            	}break;
        	case 4 : {
                $hari = 'kamis';
            	}break;
        	case 5 : {
                $hari = "jum'at";
            	}break;
        	case 6 : {
                $hari = 'sabtu';
            	}break;
        	default: {
                $hari = 'UnKnown';
            	}break;} 
    	$tanggalIndonesia = "".$tgl . " " . $bln . " " . $thn;
    	return $tanggalIndonesia; }?>        
    	  <span class="style24">Nomor : <?php echo $id_peminjam?>/LL7/TU.BMN/<?php echo date('Y')?></span></p>
    	<p>&nbsp;</p></td>
        </tr>
        </table>
          <p>Kepala Bagian Umum Lembaga Layanan Pendidikan Tinggi Wilayah VII, memberi izin penggunaan Barang Milik Negara kepada :        </p>
            <div class="style24" style="text-align: justify;">
              <?php while($row = $config->select($sql)){
                  if($row['peruntukan'] != $peruntukan){
                      msg("failed","Failed!","Gagal mencetak , terdapat peruntukan yang berbeda");
                      echo '<script>window.location.href="'.$config->site_url().'index.php?page=cetak-peminjaman"</script>';                  }
                  $peruntukan=$row['peruntukan'];
              } $row = $config->select($sql);?>
<?php
$jabatan1;
	if($unit=='Kepala Bagian Umum'){$jabatan1 = 'Kepala';
?>                          
                          <?php }
                              else{ $jabatan1 = 'Kepala Bagian Umum' ?>
                          <?php   }
                              $sql3 = $config->query("SELECT * from datapegawai where jabatan = '$jabatan1'");
							  $row3 = $config->select($sql3);
                              $namaketua = $row3['nama'];
                              $nipketua = $row3['nip'];
                              ?>
<table width="705" cellpadding="2">
  <tr>
    <td width="146" height="20" valign="top" class="style24">Nama </td>
    <td width="8" valign="top" class="style24">:</td>
    <td width="529" valign="top" class="style24"><?php echo $nama?></td>
  </tr>
  <tr>
    <td height="20" valign="top" class="style24">NIP </td>
    <td valign="top" class="style24">:</td>
    <td valign="top" class="style24"><?php echo $nip?></td>
  </tr>
  <tr>
    <td height="20" valign="top" class="style24">Jabatan </td>
    <td valign="top" class="style24">:</td>
    <td valign="top" class="style24"><?php echo $jabatan?></td>
  </tr>
  <tr>
    <td height="20" valign="top" class="style24">Ruangan </td>
    <td valign="top" class="style24">:</td>
    <td valign="top" class="style24"><?php echo $unit?></td>
  </tr>
</table>
          <p class="style10">Sebagai Pemegang dan Pengguna Barang Milik Negara.</p>
		 
                <table width="705" cellpadding="2">
				  <tr>
                    <td width="147" height="20" valign="top"><span class="style24">1. Nama Barang </span></td>
                    <td width="8" valign="top"><span class="style24">:</span></td>
                    <td width="537" valign="top"><span class="style24"><?php echo $nama_barang?></span></td>
                  </tr>
                  <tr>
                    <td height="20" valign="top"><span class="style24">2. Kode Barang-NUP </span></td>
                    <td valign="top"><span class="style24">:</span></td>
                    <td valign="top"><span class="style24"><?php echo $kode_barang?>-<?php echo $nup?></span></td>
                  </tr>
                  <tr>
                    <td height="20" valign="top"><span class="style24">3. Tahun </span></td>
                    <td width="8" valign="top"><span class="style24">:</span></td>
                    <td width="537" valign="top"><span class="style24"><?php echo $tahun?></span></td>
                  </tr>
                  <tr>
                    <td height="20" valign="top"><span class="style24">4. Merk/Type </span></td>
                    <td width="8" valign="top"><span class="style24">:</span></td>
                    <td width="537" valign="top"><span class="style24"><?php echo $tipe?></span></td>
                  </tr>
                  <tr>
                    <td height="20" valign="top"><span class="style24">5. S/N </span></td>
                    <td width="8" valign="top"><span class="style24">:</span></td>
                    <td width="537" valign="top"><span class="style24"><?php echo $sn?></span></td>
                  </tr>
                  <tr>
                    <td height="20" valign="top"><span class="style24">6. Kelengkapan </span></td>
                    <td width="8" valign="top"><span class="style24">:</span></td>
                    <td width="537" valign="top"><span class="style24"><?php echo $keterangan?></span></td>
                  </tr>
                  <tr>
                    <td height="20" valign="top">&nbsp;</td>
                    <td valign="top">&nbsp;</td>
                    <td valign="top">&nbsp;</td>
                  </tr>
                </table>
       	</div>
            <span class="style41">Dengan ketentuan sebagai berikut :</span>
<table width="962" cellpadding="2">
            <tr>
              <td height="20" valign="top" class="style10"><p>1.</p></td>
              <td valign="top" class="style10"><p>BMN tersebut digunakan untuk mendukung tugas dan fungsi jabatan tersebut;</p></td>
            </tr>
            <tr>
              <td height="20" valign="top" class="style10"><p>2.</p></td>
              <td valign="top" class="style10"><p>Pengguna BMN tersebut wajib memelihara dengan sebaik-baiknya;</p></td>
            </tr>
            <tr>
              <td height="20" valign="top" class="style10"><p>3.</p></td>
              <td valign="top" class="style10"><p>BMN tersebut harus siap digunakan untuk kepentingan kantor apabila sewaktu-waktu dibutuhkan;</p></td>
            </tr>
            <tr>
              <td height="20" valign="top" class="style10"><p>4.</p></td>
              <td valign="top" class="style10"><p>Jika terjadi kehilangan/kerusakan terhadap BMN tersebut akibat dari kelalaian Pengguna, maka Pengguna BMN yang bersangkutan wajib mengganti sesuai 
                peraturan perundang-undangan;</p></td>
            </tr>
            <tr>
              <td height="20" valign="top" class="style10"><p>5.</p></td>
              <td valign="top" class="style10"><p>Apabila pengguna BMN tidak lagi bekerja (pensiun), pindah Satuan kerja di luar LLDIKTI Wilayah VII atau pindah sub koordinasi di dalam LLDIKTI Wilayah VII, 		 				maka BMN yang digunakan harus dikembalikan ke Sub Koordinasi Tata Usaha LLDIKTI Wilayah VII; dan </p></td>
            </tr>
            <tr>
              <td height="20" valign="top" class="style10"><p>6.</p></td>
              <td valign="top" class="style10"><p>Jika terjadi kendala terkait penggunaan BMN dimohon segera menginformasikan ke Sub Koordinasi Tata Usaha.</p></td>
            </tr>
            
            <tr>
              <td height="20" valign="top" class="style12">&nbsp;</td>
              <td valign="top" class="style12">&nbsp;</td>
            </tr>
        </table>
          <p align="justify" class="style10">Surat Izin ini berlaku mulai tanggal ditetapkan.</p>
          <table width="909" cellpadding="2">
             <tr>
    			<td width="162" height="20" valign="top"></td>
    			<td width="347" valign="top"></td>
   			   <td width="378" valign="top" class="style10"><span class="style10">Ditetapkan di : Surabaya </span></td>
  			</tr
			><tr>
              <td width="162" height="20" valign="top"></td>
              <td width="347" valign="top"></td>
              <td width="378" valign="top" class="style10"><span class="style10">Pada tanggal  : 
               <?= TanggalIndonesia(date($ts)) ?>
              </p>
              </span></td>
            </tr>
        </table>
          <div style="text-align: justify;">
            <table width="909" cellpadding="2">
              <tr>
                <td width="358" height="49" valign="top" class="style10"><div align="left" class="style14">
                  <p><span class="style10">Pemegang dan Pengguna BMN, </span><br />
                    <br />
                  </p>
                  <p><br />
                    <br />
                    <span class="style10"><?php echo $nama?><br />
NIP <?php echo $nip ?></span></div></td>
                <td width="153" valign="top" class="style10"><span class="style23"></span></td>
                <td width="376" valign="top" class="style10"><div align="left" class="style14"><span class="style10"><?php echo $jabatan1?>,
                    </span>
                  <p><br />
                  </p>
                  <p><br />
                    <span class="style10"><br />
                    <?php echo $namaketua?><br />
NIP <?php echo $nipketua ?></span> </p>
                </div></td>
              </tr>
            </table>
            <table width="705" cellpadding="2">
              <tr>
                <td width="100" height="20" valign="top" class="style10"><span class="style10">Tembusan : </span></td>
              </tr>
              <tr>
                <td height="20" valign="top" class="style10"><span class="style10">1. Kepala LLDIKTI Wilayah VII </span></td>
              </tr>
              <tr>
                <td height="20" valign="top" class="style10"><span class="style10">2. Penanggung Jawab Ruangan </span></td>
              </tr>
            </table>
            <p>&nbsp;</p>
        </div>
          <div style="text-align: justify;">
            <!--?php echo $jabatan1?-->
            <!--?php echo $unit?-->
        </div>
          
          <!--div style="text-align: justify;"-->
    </div>
  </div>
  </div>