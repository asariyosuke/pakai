  <header class="main-header">
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>      </a>
      <div class="col-md-1">
                <img style="; height: 60px;" src="img/logo2.png" alt="">      </div>
      <!-- logo for regular state and mobile devices -->
      <h1 style="margin: 12px 0 0 0; color: #FFFF00;"><span>APLIKASI IJIN PAKAI BMN LLDIKTI WILAYAH VII</span></h1>

    </nav>
  </header>
